/*
  Kickoff desk — Waveshare ESP32-S3-Touch-LCD-7.
  Pro games, a countdown to the next kickoff, a favorite team,
  and a temperature card for a city you pick. Prefs name kick7.
  Arduino: ESP32S3 Dev Module, PSRAM OPI PSRAM, Flash 16MB,
  USB CDC On Boot Disabled,
  Partition 16M Flash (3MB APP/9.9MB FATFS).
  Screen clock 12500000, bounce 800 * 20. Not the Sunton 7 inch.
*/

#include <Arduino_GFX_Library.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <Wire.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <Update.h>
#include "esp_ota_ops.h"
#include "team_marks.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define SW 800
#define SH 480
#define PREF_NS "kick7"
#define TOUCH_SDA 8
#define TOUCH_SCL 9
#define TOUCH_INT 4
#define GT911_ADDR 0x5D
#define CH422_WR_SET 0x24
#define CH422_WR_IO 0x38
#define EXIO_TP_RST 1
#define EXIO_LCD_BL 2
#define EXIO_LCD_RST 3
#define EXIO_SD_CS 4

#define KICK_VER "1.0"
#define KICK_GH_USER "stefi01"
#define KICK_GH_REPO "esp32-scoreboard"
#define KICK_BIN "kick_7.bin"
enum { PG_BOARD = 0, PG_NEXT, PG_SKY, PG_TEAM, PG_WIFI, PG_UPD };

struct Kick {
  char name[20];
  char away[4];
  char home[4];
  char detail[36];
  char score[16];
  char aPts[6];
  char hPts[6];
  char state[8];
  time_t start;
};

struct City {
  const char *name;
  float lat, lon;
};

struct Key {
  int16_t x, y, w, h, code;
};

const City CITIES[] = {
    {"Fresno", 36.7378f, -119.7871f},
    {"Los Angeles", 34.0522f, -118.2437f},
    {"San Diego", 32.7157f, -117.1611f},
    {"San Francisco", 37.7749f, -122.4194f},
    {"Sacramento", 38.5816f, -121.4944f},
    {"Seattle", 47.6062f, -122.3321f},
    {"Portland", 45.5152f, -122.6784f},
    {"Phoenix", 33.4484f, -112.0740f},
    {"Las Vegas", 36.1699f, -115.1398f},
    {"Denver", 39.7392f, -104.9903f},
    {"Salt Lake City", 40.7608f, -111.8910f},
    {"Albuquerque", 35.0844f, -106.6504f},
    {"Dallas", 32.7767f, -96.7970f},
    {"Houston", 29.7604f, -95.3698f},
    {"Kansas City", 39.0997f, -94.5786f},
    {"Minneapolis", 44.9778f, -93.2650f},
    {"Chicago", 41.8781f, -87.6298f},
    {"Green Bay", 44.5133f, -88.0133f},
    {"Detroit", 42.3314f, -83.0458f},
    {"Atlanta", 33.7490f, -84.3880f},
    {"Miami", 25.7617f, -80.1918f},
    {"New Orleans", 29.9511f, -90.0715f},
    {"Nashville", 36.1627f, -86.7816f},
    {"St Louis", 38.6270f, -90.1994f},
    {"Boston", 42.3601f, -71.0589f},
    {"New York", 40.7128f, -74.0060f},
    {"Philadelphia", 39.9526f, -75.1652f},
    {"Washington", 38.9072f, -77.0369f},
    {"Charlotte", 35.2271f, -80.8431f},
    {"Anchorage", 61.2181f, -149.9003f},
    {"Honolulu", 21.3069f, -157.8583f},
    {"San Jose", 37.3382f, -121.8863f},
    {"Oakland", 37.8044f, -122.2712f},
    {"Bakersfield", 35.3733f, -119.0187f},
    {"Long Beach", 33.7701f, -118.1937f},
    {"Tucson", 32.2226f, -110.9747f},
    {"Flagstaff", 35.1983f, -111.6513f},
    {"Reno", 39.5296f, -119.8138f},
    {"Henderson", 36.0395f, -114.9817f},
    {"Spokane", 47.6588f, -117.4260f},
    {"Tacoma", 47.2529f, -122.4443f},
    {"Eugene", 44.0521f, -123.0868f},
    {"Salem", 44.9429f, -123.0351f},
    {"Bend", 44.0582f, -121.3153f},
    {"Boise", 43.6150f, -116.2023f},
    {"Idaho Falls", 43.4917f, -112.0339f},
    {"Colorado Springs", 38.8339f, -104.8214f},
    {"Boulder", 40.0150f, -105.2705f},
    {"Provo", 40.2338f, -111.6585f},
    {"Ogden", 41.2230f, -111.9738f},
    {"Santa Fe", 35.6870f, -105.9378f},
    {"Las Cruces", 32.3199f, -106.7637f},
    {"Billings", 45.7833f, -108.5007f},
    {"Missoula", 46.8721f, -113.9940f},
    {"Helena", 46.5891f, -112.0391f},
    {"Cheyenne", 41.1400f, -104.8202f},
    {"Casper", 42.8666f, -106.3131f},
    {"Austin", 30.2672f, -97.7431f},
    {"San Antonio", 29.4241f, -98.4936f},
    {"Fort Worth", 32.7555f, -97.3308f},
    {"El Paso", 31.7619f, -106.4850f},
    {"Lubbock", 33.5779f, -101.8552f},
    {"Corpus Christi", 27.8006f, -97.3964f},
    {"Oklahoma City", 35.4676f, -97.5164f},
    {"Tulsa", 36.1540f, -95.9928f},
    {"Wichita", 37.6872f, -97.3301f},
    {"Topeka", 39.0473f, -95.6752f},
    {"Omaha", 41.2565f, -95.9345f},
    {"Lincoln", 40.8136f, -96.7026f},
    {"Des Moines", 41.5868f, -93.6250f},
    {"Cedar Rapids", 41.9779f, -91.6656f},
    {"Sioux Falls", 43.5460f, -96.7313f},
    {"Rapid City", 44.0805f, -103.2310f},
    {"Fargo", 46.8772f, -96.7898f},
    {"Bismarck", 46.8083f, -100.7837f},
    {"Little Rock", 34.7465f, -92.2896f},
    {"Fayetteville", 36.0626f, -94.1574f},
    {"Indianapolis", 39.7684f, -86.1581f},
    {"Fort Wayne", 41.0793f, -85.1394f},
    {"South Bend", 41.6764f, -86.2520f},
    {"Columbus", 39.9612f, -82.9988f},
    {"Cleveland", 41.4993f, -81.6944f},
    {"Cincinnati", 39.1031f, -84.5120f},
    {"Toledo", 41.6528f, -83.5379f},
    {"Dayton", 39.7589f, -84.1916f},
    {"Milwaukee", 43.0389f, -87.9065f},
    {"Madison", 43.0731f, -89.4012f},
    {"Grand Rapids", 42.9634f, -85.6681f},
    {"Lansing", 42.7325f, -84.5555f},
    {"Ann Arbor", 42.2808f, -83.7430f},
    {"Springfield", 39.7817f, -89.6501f},
    {"Rockford", 42.2711f, -89.0940f},
    {"Peoria", 40.6936f, -89.5890f},
    {"St Paul", 44.9537f, -93.0900f},
    {"Duluth", 46.7867f, -92.1005f},
    {"Rochester MN", 44.0121f, -92.4802f},
    {"Louisville", 38.2527f, -85.7585f},
    {"Lexington", 38.0406f, -84.5037f},
    {"Springfield MO", 37.2090f, -93.2923f},
    {"Columbia MO", 38.9517f, -92.3341f},
    {"Memphis", 35.1495f, -90.0490f},
    {"Knoxville", 35.9606f, -83.9207f},
    {"Chattanooga", 35.0456f, -85.3097f},
    {"Birmingham", 33.5207f, -86.8025f},
    {"Mobile", 30.6954f, -88.0399f},
    {"Montgomery", 32.3792f, -86.3077f},
    {"Jackson", 32.2988f, -90.1848f},
    {"Gulfport", 30.3674f, -89.0928f},
    {"Baton Rouge", 30.4515f, -91.1871f},
    {"Shreveport", 32.5252f, -93.7502f},
    {"Tampa", 27.9506f, -82.4572f},
    {"Orlando", 28.5383f, -81.3792f},
    {"Jacksonville", 30.3322f, -81.6557f},
    {"Tallahassee", 30.4383f, -84.2807f},
    {"Savannah", 32.0809f, -81.0912f},
    {"Augusta", 33.4735f, -82.0105f},
    {"Raleigh", 35.7796f, -78.6382f},
    {"Greensboro", 36.0726f, -79.7920f},
    {"Asheville", 35.5951f, -82.5515f},
    {"Charleston", 32.7765f, -79.9311f},
    {"Columbia", 34.0007f, -81.0348f},
    {"Greenville", 34.8526f, -82.3940f},
    {"Richmond", 37.5407f, -77.4360f},
    {"Virginia Beach", 36.8529f, -75.9780f},
    {"Norfolk", 36.8508f, -76.2859f},
    {"Roanoke", 37.2710f, -79.9414f},
    {"Baltimore", 39.2904f, -76.6122f},
    {"Annapolis", 38.9784f, -76.4922f},
    {"Charleston WV", 38.3498f, -81.6326f},
    {"Huntington", 38.4192f, -82.4452f},
    {"Pittsburgh", 40.4406f, -79.9959f},
    {"Harrisburg", 40.2732f, -76.8867f},
    {"Allentown", 40.6084f, -75.4902f},
    {"Buffalo", 42.8864f, -78.8784f},
    {"Rochester", 43.1566f, -77.6088f},
    {"Albany", 42.6526f, -73.7562f},
    {"Syracuse", 43.0481f, -76.1474f},
    {"Newark", 40.7357f, -74.1724f},
    {"Jersey City", 40.7178f, -74.0431f},
    {"Trenton", 40.2204f, -74.7699f},
    {"Atlantic City", 39.3643f, -74.4229f},
    {"Hartford", 41.7658f, -72.6734f},
    {"New Haven", 41.3083f, -72.9279f},
    {"Bridgeport", 41.1865f, -73.1952f},
    {"Providence", 41.8240f, -71.4128f},
    {"Worcester", 42.2626f, -71.8023f},
    {"Springfield MA", 42.1015f, -72.5898f},
    {"Manchester", 42.9956f, -71.4548f},
    {"Concord", 43.2081f, -71.5376f},
    {"Portland ME", 43.6591f, -70.2568f},
    {"Bangor", 44.8016f, -68.7712f},
    {"Burlington", 44.4759f, -73.2121f},
    {"Wilmington", 39.7391f, -75.5398f},
    {"Dover", 39.1582f, -75.5244f},
    {"Fairbanks", 64.8378f, -147.7164f},
    {"Juneau", 58.3019f, -134.4197f},
};
const int N_CITIES = sizeof(CITIES) / sizeof(CITIES[0]);

const char *TEAMS[] = {
    "ARI", "ATL", "BAL", "BUF", "CAR", "CHI", "CIN", "CLE",
    "DAL", "DEN", "DET", "GB",  "HOU", "IND", "JAX", "KC",
    "LAC", "LAR", "LV",  "MIA", "MIN", "NE",  "NO",  "NYG",
    "NYJ", "PHI", "PIT", "SEA", "SF",  "TB",  "TEN", "WAS",
};
const int N_TEAMS = 32;

const char *TZS[] = {
    "PST8PDT,M3.2.0,M11.1.0",
    "MST7MDT,M3.2.0,M11.1.0",
    "CST6CDT,M3.2.0,M11.1.0",
    "EST5EDT,M3.2.0,M11.1.0",
};
const char *TZLAB[] = {"Pacific", "Mountain", "Central", "Eastern"};

const uint16_t COL_BG = 0x0841;
const uint16_t COL_CARD = 0x2124;
const uint16_t COL_GOLD = 0xFE60;
const uint16_t COL_WHITE = 0xFFFF;
const uint16_t COL_DIM = 0xBDF7;
const uint16_t COL_GREEN = 0x07E0;
const uint16_t COL_LINE = 0x4208;

Arduino_ESP32RGBPanel *rgbBus = nullptr;
Arduino_GFX *gfx = nullptr;
Preferences prefs;
uint8_t ch422Io = 0;

Kick games[16];
int nGames = 0;
SemaphoreHandle_t gameLock = nullptr;

char wifiSsid[33];
char wifiPass[65];
char fav[8];
int cityIx = 0;
int tzIx = 0;
bool useC = false;
int page = PG_BOARD;
int gTop = 0;
bool wifiOk = false;
bool skyOk = false;
float skyTemp = 0, skyWind = 0;
int skyCode = 0;
char scanName[4][33];
int nScan = 0;
bool scanWait = false;
bool keysNum = false;
int wifiFocus = 0;
Key keys[48];
int nKeys = 0;
volatile int job = 0;
volatile bool busy = false;
volatile bool dirty = false;
uint32_t lastGames = 0;
uint32_t lastSky = 0;
uint32_t lastTap = 0;
uint32_t shownAt = 0;
int shownMin = -1;
int bigX = 0, bigY = 0, bigW = 0, bigH = 0;
char otaMsg[48];
char otaLatest[12];
volatile int otaPct = -1;
volatile int otaBusy = 0;
volatile int otaRev = 0;
int otaNewer = 0;
int otaKind = 0;
int shownRev = 0;
int updX = 0, updY1 = 0, updY2 = 0, updBw = 0, updBh = 0;

bool hit(int x, int y, int x0, int y0, int x1, int y1) {
  return x >= x0 && x < x1 && y >= y0 && y < y1;
}

void ch422Write(uint8_t addr, uint8_t val) {
  Wire.beginTransmission(addr);
  Wire.write(val);
  Wire.endTransmission();
}

void ch422Bit(int bit, bool on) {
  if (on) ch422Io |= (uint8_t)(1u << bit);
  else ch422Io &= (uint8_t)~(1u << bit);
  Wire.beginTransmission(CH422_WR_IO);
  Wire.write(ch422Io);
  Wire.endTransmission();
}

void boardIoBegin() {
  Wire.begin(TOUCH_SDA, TOUCH_SCL);
  ch422Write(CH422_WR_SET, 0x01);
  delay(2);
  ch422Io = (uint8_t)((1u << EXIO_TP_RST) | (1u << EXIO_LCD_RST) | (1u << EXIO_SD_CS));
  ch422Write(CH422_WR_IO, ch422Io);
  pinMode(TOUCH_INT, OUTPUT);
  digitalWrite(TOUCH_INT, LOW);
  ch422Bit(EXIO_TP_RST, false);
  delay(10);
  ch422Bit(EXIO_TP_RST, true);
  delay(50);
  pinMode(TOUCH_INT, INPUT);
}

int readFinger(int *x, int *y) {
  Wire.beginTransmission(GT911_ADDR);
  Wire.write(0x81);
  Wire.write(0x4E);
  if (Wire.endTransmission(false) != 0) return 0;
  if (Wire.requestFrom((uint8_t)GT911_ADDR, (uint8_t)1) != 1) return 0;
  uint8_t st = Wire.read();
  if ((st & 0x80) == 0) return 0;
  int n = st & 0x0F;
  if (n <= 0) {
    Wire.beginTransmission(GT911_ADDR);
    Wire.write(0x81);
    Wire.write(0x4E);
    Wire.write(0);
    Wire.endTransmission();
    return 0;
  }
  Wire.beginTransmission(GT911_ADDR);
  Wire.write(0x81);
  Wire.write(0x50);
  if (Wire.endTransmission(false) != 0) return 0;
  if (Wire.requestFrom((uint8_t)GT911_ADDR, (uint8_t)8) != 8) return 0;
  uint8_t p[8];
  for (int i = 0; i < 8; i++) p[i] = Wire.read();
  Wire.beginTransmission(GT911_ADDR);
  Wire.write(0x81);
  Wire.write(0x4E);
  Wire.write(0);
  Wire.endTransmission();
  *x = constrain(p[0] | (p[1] << 8), 0, SW - 1);
  *y = constrain(p[2] | (p[3] << 8), 0, SH - 1);
  return 1;
}

void applyTz() {
  if (tzIx < 0 || tzIx > 3) tzIx = 0;
  setenv("TZ", TZS[tzIx], 1);
  tzset();
}

void savePrefs() {
  prefs.begin(PREF_NS, false);
  prefs.putString("ssid", wifiSsid);
  prefs.putString("pass", wifiPass);
  prefs.putString("fav", fav);
  prefs.putInt("city", cityIx);
  prefs.putInt("tz", tzIx);
  prefs.putBool("c", useC);
  prefs.end();
}

void loadPrefs() {
  wifiSsid[0] = wifiPass[0] = fav[0] = 0;
  prefs.begin(PREF_NS, true);
  prefs.getString("ssid", wifiSsid, sizeof(wifiSsid));
  prefs.getString("pass", wifiPass, sizeof(wifiPass));
  prefs.getString("fav", fav, sizeof(fav));
  cityIx = prefs.getInt("city", 0);
  tzIx = prefs.getInt("tz", 0);
  useC = prefs.getBool("c", false);
  prefs.end();
  if (cityIx < 0 || cityIx >= N_CITIES) cityIx = 0;
  applyTz();
}

bool scoreRose(const Kick *oldg, const Kick *now) {
  if (!oldg->aPts[0] && !oldg->hPts[0]) return false;
  if (atoi(now->aPts) > atoi(oldg->aPts)) return true;
  if (atoi(now->hPts) > atoi(oldg->hPts)) return true;
  return false;
}

void publishGames(Kick *src, int n) {
  if (n < 0) n = 0;
  if (n > 16) n = 16;
  Kick ordered[16];
  if (n > 0) memcpy(ordered, src, sizeof(Kick) * n);
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  if (n > 0 && nGames > 0) {
    int top[16], rest[16], nt = 0, nr = 0;
    for (int i = 0; i < n; i++) {
      const Kick *oldg = nullptr;
      for (int j = 0; j < nGames; j++) {
        if (strcmp(games[j].name, ordered[i].name) == 0) {
          oldg = &games[j];
          break;
        }
      }
      if (oldg && scoreRose(oldg, &ordered[i])) top[nt++] = i;
      else rest[nr++] = i;
    }
    if (nt > 0) {
      Kick tmp[16];
      int k = 0;
      for (int i = 0; i < nt; i++) tmp[k++] = ordered[top[i]];
      for (int i = 0; i < nr; i++) tmp[k++] = ordered[rest[i]];
      memcpy(ordered, tmp, sizeof(Kick) * n);
      gTop = 0;
    }
  }
  nGames = n;
  if (n > 0) memcpy(games, ordered, sizeof(Kick) * n);
  if (gameLock) xSemaphoreGive(gameLock);
}

int copyGames(Kick *dst) {
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  int n = nGames;
  if (n > 0) memcpy(dst, games, sizeof(Kick) * n);
  if (gameLock) xSemaphoreGive(gameLock);
  return n;
}

bool grab(const char *p, const char *key, char *out, int cap) {
  const char *f = strstr(p, key);
  out[0] = 0;
  if (!f) return false;
  f += strlen(key);
  int i = 0;
  while (f[i] && f[i] != '"' && i < cap - 1) {
    out[i] = f[i];
    i++;
  }
  out[i] = 0;
  return i > 0;
}

time_t utcParts(int y, int mo, int d, int h, int mi) {
  struct tm t;
  memset(&t, 0, sizeof(t));
  t.tm_year = y - 1900;
  t.tm_mon = mo - 1;
  t.tm_mday = d;
  t.tm_hour = h;
  t.tm_min = mi;
  char saved[48];
  const char *cur = getenv("TZ");
  saved[0] = 0;
  if (cur) strlcpy(saved, cur, sizeof(saved));
  setenv("TZ", "UTC0", 1);
  tzset();
  time_t u = mktime(&t);
  if (saved[0]) setenv("TZ", saved, 1);
  else unsetenv("TZ");
  tzset();
  return u;
}

void splitClubs(Kick *g) {
  g->away[0] = 0;
  g->home[0] = 0;
  const char *at = strstr(g->name, " @ ");
  if (!at) return;
  int n = (int)(at - g->name);
  if (n > 3) n = 3;
  if (n < 0) n = 0;
  memcpy(g->away, g->name, (size_t)n);
  g->away[n] = 0;
  strlcpy(g->home, at + 3, sizeof(g->home));
  if (strlen(g->home) > 3) g->home[3] = 0;
}

void clubScore(const char *block, const char *ab, char *out, int cap) {
  out[0] = 0;
  if (!ab || !ab[0]) return;
  char key[28];
  snprintf(key, sizeof(key), "\"abbreviation\":\"%s\"", ab);
  const char *p = block;
  while ((p = strstr(p, key)) != nullptr) {
    const char *from = p - 240;
    if (from < block) from = block;
    bool side = false;
    for (const char *q = from; q + 12 < p + 180; q++) {
      if (strncmp(q, "\"homeAway\":\"", 12) == 0) {
        side = true;
        break;
      }
    }
    if (!side) {
      p += 8;
      continue;
    }
    const char *sc = nullptr;
    for (const char *q = p; q >= from + 9; q--) {
      if (strncmp(q, "\"score\":\"", 9) == 0) {
        sc = q;
        break;
      }
    }
    if (!sc) {
      sc = strstr(p, "\"score\":\"");
      if (sc && sc > p + 200) sc = nullptr;
    }
    if (sc) grab(sc, "\"score\":\"", out, cap);
    return;
  }
}

bool takeGame(const char *block, const char *win, const char *at, Kick *g) {
  memset(g, 0, sizeof(*g));
  const char *name = block + 13;
  int i = 0;
  while (name[i] && name[i] != '"' && i < (int)sizeof(g->name) - 1) {
    g->name[i] = name[i];
    i++;
  }
  g->name[i] = 0;
  if (!strstr(g->name, " @ ")) return false;
  splitClubs(g);
  grab(block, "\"shortDetail\":\"", g->detail, sizeof(g->detail));
  grab(block, "\"state\":\"", g->state, sizeof(g->state));
  clubScore(block, g->away, g->aPts, sizeof(g->aPts));
  clubScore(block, g->home, g->hPts, sizeof(g->hPts));
  if (strcmp(g->state, "pre") != 0 && g->aPts[0] && g->hPts[0])
    snprintf(g->score, sizeof(g->score), "%s-%s", g->aPts, g->hPts);
  char *from = (char *)at - 500;
  if (from < win) from = (char *)win;
  for (char *q = (char *)at; q >= from; q--) {
    if (strncmp(q, "\"date\":\"", 8) == 0) {
      int y, mo, d, h, mi;
      if (sscanf(q + 8, "%d-%d-%dT%d:%d", &y, &mo, &d, &h, &mi) == 5) g->start = utcParts(y, mo, d, h, mi);
      break;
    }
  }
  return true;
}

int eatGames(char *win, int *fill, Kick *staging, int n, bool force) {
  while (n < 16) {
    char *at = strstr(win, "\"shortName\":\"");
    if (!at) break;
    int pos = (int)(at - win);
    int tail = *fill - pos;
    char *next = strstr(at + 13, "\"shortName\":\"");
    if (!next && !force && tail < 900) break;
    if (!next && force && !strstr(at, "\"shortDetail\":\"")) break;
    int block = next ? (int)(next - at) : tail;
    if (block > 1800) block = 1800;
    if (block < 14) break;
    static char blockBuf[1801];
    memcpy(blockBuf, at, block);
    blockBuf[block] = 0;
    if (takeGame(blockBuf, win, at, &staging[n])) n++;
    int drop = pos + 13;
    if (drop <= 0 || drop > *fill) break;
    memmove(win, win + drop, *fill - drop);
    *fill -= drop;
    win[*fill] = 0;
  }
  return n;
}

int pullGames() {
  static char win[2400];
  static Kick staging[16];
  int n = 0;
  int fill = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(15000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard")) return 0;
  int code = http.GET();
  if (code != 200) {
    http.end();
    cli.stop();
    return 0;
  }
  WiFiClient *stream = http.getStreamPtr();
  uint32_t t0 = millis();
  while (millis() - t0 < 15000) {
    if (fill > 1600) {
      n = eatGames(win, &fill, staging, n, false);
      if (fill > 1600) {
        char *at = strstr(win, "\"shortName\":\"");
        if (at && at > win) {
          int pos = (int)(at - win);
          memmove(win, at, fill - pos);
          fill -= pos;
        } else if (!at) {
          memmove(win, win + fill - 400, 400);
          fill = 400;
        }
        win[fill] = 0;
      }
    }
    int space = (int)sizeof(win) - 1 - fill;
    if (space < 80) break;
    int avail = stream->available();
    if (avail <= 0) {
      if (!http.connected()) break;
      delay(4);
      continue;
    }
    if (avail > space) avail = space;
    int r = stream->read((uint8_t *)win + fill, avail);
    if (r <= 0) break;
    fill += r;
    win[fill] = 0;
  }
  http.end();
  cli.stop();
  n = eatGames(win, &fill, staging, n, true);
  publishGames(staging, n);
  return n;
}

const char *skyWord(int code) {
  if (code == 0) return "clear";
  if (code <= 3) return "cloud";
  if (code <= 48) return "fog";
  if (code <= 67) return "rain";
  if (code <= 77) return "snow";
  if (code <= 82) return "showers";
  if (code <= 86) return "snow";
  if (code >= 95) return "storm";
  return "weather";
}

bool pullSky() {
  char url[280];
  snprintf(url, sizeof(url),
           "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
           "&current=temperature_2m,weather_code,wind_speed_10m&temperature_unit=%s"
           "&wind_speed_unit=mph&timezone=auto",
           CITIES[cityIx].lat, CITIES[cityIx].lon, useC ? "celsius" : "fahrenheit");
  static char body[1400];
  body[0] = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(12000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  if (!http.begin(cli, url)) return false;
  int code = http.GET();
  if (code == 200) {
    WiFiClient *stream = http.getStreamPtr();
    int got = 0;
    uint32_t t0 = millis();
    while (got < (int)sizeof(body) - 1 && millis() - t0 < 12000) {
      int a = stream->available();
      if (a <= 0) {
        if (!http.connected()) break;
        delay(2);
        continue;
      }
      if (a > (int)sizeof(body) - 1 - got) a = (int)sizeof(body) - 1 - got;
      int r = stream->read((uint8_t *)body + got, a);
      if (r <= 0) break;
      got += r;
    }
    body[got] = 0;
  }
  http.end();
  cli.stop();
  const char *cur = strstr(body, "\"current\":{");
  if (!cur || !strstr(cur, "temperature_2m")) {
    skyOk = false;
    return false;
  }
  const char *tp = strstr(cur, "\"temperature_2m\":");
  const char *wp = strstr(cur, "\"wind_speed_10m\":");
  const char *cp = strstr(cur, "\"weather_code\":");
  if (tp) skyTemp = (float)atof(tp + 17);
  if (wp) skyWind = (float)atof(wp + 17);
  if (cp) skyCode = atoi(cp + 15);
  skyOk = tp != nullptr;
  return skyOk;
}

void netTask(void *) {
  for (;;) {
    if (job == 1) {
      pullGames();
      lastGames = millis();
      job = 0;
      busy = false;
      dirty = true;
    } else if (job == 2) {
      pullSky();
      lastSky = millis();
      job = 0;
      busy = false;
      dirty = true;
    } else if (job == 3) {
      runOtaJob();
      job = 0;
    }
    vTaskDelay(pdMS_TO_TICKS(40));
  }
}

int boardCols() { return SW >= 700 ? 2 : 1; }
int cardH() { return SH >= 400 ? 112 : 74; }

int boardRows() {
  int n = (SH - 48 - 60) / (cardH() + 6);
  if (n < 1) n = 1;
  return n;
}

bool scrollOn(int n) { return n > boardRows() * boardCols(); }

int clockX(bool scrolling) { return scrolling ? 148 : SW - 156; }

void clockText(char *out, int cap) {
  time_t now = time(nullptr);
  if (now < 100000) {
    strlcpy(out, "--:--", cap);
    return;
  }
  struct tm t;
  localtime_r(&now, &t);
  int h = t.tm_hour % 12;
  if (h == 0) h = 12;
  snprintf(out, cap, "%d:%02d %s", h, t.tm_min, t.tm_hour < 12 ? "AM" : "PM");
}

void paintChipRow() {
  const char *names[] = {"BOARD", "NEXT", "TEMP", "TEAM", "WIFI", "UPDATE"};
  int n = 6;
  int gap = 4;
  int w = (SW - 8 - gap * (n - 1)) / n;
  int y = SH - 52;
  for (int i = 0; i < n; i++) {
    int x = 4 + i * (w + gap);
    bool on = page == i;
    gfx->fillRoundRect(x, y, w, 28, 6, on ? COL_GOLD : COL_CARD);
    gfx->setTextSize(1);
    gfx->setTextColor(on ? COL_BG : COL_WHITE);
    int tw = (int)strlen(names[i]) * 6;
    gfx->setCursor(x + (w - tw) / 2, y + 10);
    gfx->print(names[i]);
  }
}

bool chipHit(int x, int y, int i) {
  int n = 6;
  int gap = 4;
  int w = (SW - 8 - gap * (n - 1)) / n;
  int bx = 4 + i * (w + gap);
  int by = SH - 52;
  return hit(x, y, bx, by, bx + w, by + 28);
}

void titleRow(const char *title, bool scrolling) {
  gfx->setTextSize(2);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, 22);
  gfx->print(title);
  char clk[16];
  clockText(clk, sizeof(clk));
  gfx->setTextSize(3);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(clockX(scrolling), 16);
  gfx->print(clk);
  if (scrolling) {
    gfx->fillRoundRect(SW - 156, 16, 70, 24, 4, COL_CARD);
    gfx->fillRoundRect(SW - 78, 16, 70, 24, 4, COL_CARD);
    gfx->setTextSize(1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(SW - 136, 22);
    gfx->print("UP");
    gfx->setCursor(SW - 58, 22);
    gfx->print("DN");
  }
}

bool hasTeam(const char *name, const char *ab) {
  if (!ab[0]) return false;
  int n = (int)strlen(ab);
  const char *p = strstr(name, ab);
  if (!p) return false;
  bool left = (p == name) || p[-1] == ' ';
  bool right = p[n] == 0 || p[n] == ' ';
  return left && right;
}

void centreAt(const char *s, int y, int size, uint16_t col) {
  gfx->setTextSize(size);
  gfx->setTextColor(col);
  int n = (int)strlen(s);
  int w = n * 6 * size;
  int x = (SW - w) / 2;
  if (x < 2) x = 2;
  gfx->setCursor(x, y);
  gfx->print(s);
}

int textFit(const char *s, int maxW, int maxH, int cap) {
  int n = (int)strlen(s);
  if (n < 1) n = 1;
  int a = maxW / (n * 6);
  int b = maxH / 8;
  int z = a < b ? a : b;
  if (z < 2) z = 2;
  if (z > cap) z = cap;
  return z;
}

int teamIx(const char *ab) {
  if (!ab) return -1;
  for (int i = 0; i < N_TEAMS; i++)
    if (strcmp(TEAMS[i], ab) == 0) return i;
  return -1;
}

void drawMark(const char *ab, int x, int y, int px) {
  int ix = teamIx(ab);
  if (ix < 0 || px < 8 || px > 32) return;
  static uint16_t buf[32 * 32];
  for (int row = 0; row < px; row++) {
    int sy = row * MARK_PX / px;
    for (int col = 0; col < px; col++) {
      int sx = col * MARK_PX / px;
      buf[row * px + col] = pgm_read_word(&MARKS[ix][sy * MARK_PX + sx]);
    }
  }
  gfx->draw16bitRGBBitmap(x, y, buf, px, px);
}

void drawSide(int x, int y, const char *ab, const char *pts, int px) {
  if (!ab || !ab[0]) return;
  drawMark(ab, x, y, px);
  int ts = px >= 28 ? 2 : 1;
  gfx->setTextSize(ts);
  gfx->setTextColor(COL_WHITE);
  int ty = y + (px - 8 * ts) / 2;
  if (ty < y) ty = y;
  gfx->setCursor(x + px + 4, ty);
  gfx->print(ab);
  if (pts && pts[0]) {
    gfx->setTextColor(COL_GOLD);
    gfx->print(" ");
    gfx->print(pts);
  }
}

void drawBoard() {
  Kick view[16];
  int n = copyGames(view);
  int cols = boardCols();
  int rows = boardRows();
  int vis = rows * cols;
  if (gTop < 0) gTop = 0;
  if (gTop > 0 && gTop >= n) gTop = 0;
  gfx->fillScreen(COL_BG);
  titleRow("KICKOFF", scrollOn(n));
  {
    int ix = pickNext(view, n);
    char left[20];
    left[0] = 0;
    if (ix >= 0 && strcmp(view[ix].state, "in") == 0) strlcpy(left, "ON NOW", sizeof(left));
    else if (ix >= 0 && view[ix].start > 100000) fmtRemain(view[ix].start, left, sizeof(left));
    if (left[0]) {
      int x = 108;
      int stop = clockX(scrollOn(n)) - 6;
      int maxc = (stop - x) / 6;
      if (maxc > 0) {
        if ((int)strlen(left) > maxc) left[maxc] = 0;
        gfx->setTextSize(1);
        gfx->setTextColor(COL_GOLD);
        gfx->setCursor(x, 26);
        gfx->print(left);
      }
    }
  }
  if (!wifiOk) {
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, 50);
    gfx->print("no link yet");
  } else if (n <= 0) {
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, 50);
    gfx->print(busy ? "reading the board" : "no games listed");
  }
  int gap = 6;
  int cw = (SW - 12 - gap * (cols - 1)) / cols;
  int ch = cardH();
  int shown = 0;
  for (int i = gTop; i < n && shown < vis; i++, shown++) {
    int col = shown % cols;
    int row = shown / cols;
    int x = 6 + col * (cw + gap);
    int y = 48 + row * (ch + gap);
    bool mine = hasTeam(view[i].name, fav);
    gfx->fillRoundRect(x, y, cw, ch, 8, COL_CARD);
    gfx->drawRoundRect(x, y, cw, ch, 8, mine ? COL_GOLD : COL_LINE);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(x + 8, y + 6);
    gfx->print(view[i].name);
    gfx->setTextSize(1);
    if (strcmp(view[i].state, "in") == 0) {
      gfx->setTextColor(COL_GREEN);
      gfx->setCursor(x + cw - 40, y + 8);
      gfx->print("LIVE");
    } else if (strcmp(view[i].state, "post") == 0) {
      gfx->setTextColor(COL_DIM);
      gfx->setCursor(x + cw - 52, y + 8);
      gfx->print("FINAL");
    }
    int px = ch >= 100 ? 32 : 20;
    int sy = y + (ch >= 100 ? 34 : 26);
    drawSide(x + 8, sy, view[i].away, view[i].aPts, px);
    drawSide(x + cw / 2, sy, view[i].home, view[i].hPts, px);
    gfx->setTextSize(1);
    gfx->setTextColor(COL_DIM);
    gfx->setCursor(x + 8, y + ch - 16);
    gfx->print(view[i].detail);
  }
  paintChipRow();
}

void fmtRemain(time_t when, char *out, int cap) {
  time_t now = time(nullptr);
  long s = (long)(when - now);
  if (s < 0) s = 0;
  int d = (int)(s / 86400);
  int h = (int)((s % 86400) / 3600);
  int m = (int)((s % 3600) / 60);
  if (d > 0) snprintf(out, cap, "%dd %dh %dm", d, h, m);
  else snprintf(out, cap, "%dh %dm", h, m);
}

int pickNext(Kick *view, int n) {
  time_t now = time(nullptr);
  int liveFav = -1, liveAny = -1, futFav = -1, futAny = -1;
  time_t soon = 0;
  for (int i = 0; i < n; i++) {
    if (strcmp(view[i].state, "in") == 0) {
      if (liveAny < 0) liveAny = i;
      if (hasTeam(view[i].name, fav)) liveFav = i;
    }
    if (view[i].start > now + 20) {
      if (futAny < 0 || view[i].start < soon) {
        futAny = i;
        soon = view[i].start;
      }
      if (hasTeam(view[i].name, fav)) {
        if (futFav < 0 || view[i].start < view[futFav].start) futFav = i;
      }
    }
  }
  if (liveFav >= 0) return liveFav;
  if (liveAny >= 0) return liveAny;
  if (futFav >= 0) return futFav;
  return futAny;
}

void drawRemainBig(time_t when, int y0, int y1) {
  time_t now = time(nullptr);
  long s = (long)(when - now);
  if (s < 0) s = 0;
  int d = (int)(s / 86400);
  int h = (int)((s % 86400) / 3600);
  int m = (int)((s % 3600) / 60);
  char da[8], ha[8], ma[8];
  const char *num[3];
  const char *lab[3];
  int n;
  if (d > 0) {
    snprintf(da, sizeof(da), "%d", d);
    snprintf(ha, sizeof(ha), "%d", h);
    snprintf(ma, sizeof(ma), "%d", m);
    num[0] = da;
    lab[0] = "DAYS";
    num[1] = ha;
    lab[1] = "HOURS";
    num[2] = ma;
    lab[2] = "MIN";
    n = 3;
  } else {
    snprintf(ha, sizeof(ha), "%d", h);
    snprintf(ma, sizeof(ma), "%d", m);
    num[0] = ha;
    lab[0] = "HOURS";
    num[1] = ma;
    lab[1] = "MIN";
    n = 2;
  }
  int gap = 8;
  int cw = (SW - 16 - gap * (n - 1)) / n;
  int labPx = SH >= 400 ? 20 : 12;
  int numH = (y1 - y0) - labPx - 4;
  if (numH < 24) numH = 24;
  int sz = 16;
  for (int i = 0; i < n; i++) {
    int z = textFit(num[i], cw - 4, numH, 14);
    if (z < sz) sz = z;
  }
  int labSize = SH >= 400 ? 2 : 1;
  for (int i = 0; i < n; i++) {
    int x = 8 + i * (cw + gap);
    int nw = (int)strlen(num[i]) * 6 * sz;
    gfx->setTextSize(sz);
    gfx->setTextColor(COL_GOLD);
    gfx->setCursor(x + (cw - nw) / 2, y0);
    gfx->print(num[i]);
    int lw = (int)strlen(lab[i]) * 6 * labSize;
    gfx->setTextSize(labSize);
    gfx->setTextColor(COL_DIM);
    gfx->setCursor(x + (cw - lw) / 2, y0 + sz * 8 + 2);
    gfx->print(lab[i]);
  }
}

void drawNext() {
  Kick view[16];
  int n = copyGames(view);
  int ix = pickNext(view, n);
  gfx->fillScreen(COL_BG);
  titleRow("NEXT", false);
  int y = SH >= 400 ? 40 : 32;
  char clk[16];
  clockText(clk, sizeof(clk));
  int clkSize = SH >= 400 ? 6 : 4;
  if (ix >= 0) {
    int ns = SH >= 400 ? 3 : 2;
    centreAt(view[ix].name, y, ns, COL_WHITE);
    y += ns * 8 + (SH >= 400 ? 8 : 2);
  }
  int clkW = (int)strlen(clk) * 6 * clkSize;
  bigX = (SW - clkW) / 2;
  if (bigX < 2) bigX = 2;
  bigY = y;
  bigW = clkW;
  bigH = clkSize * 8;
  centreAt(clk, y, clkSize, COL_WHITE);
  y += bigH + 2;
  int zs = SH >= 400 ? 2 : 1;
  centreAt(TZLAB[tzIx], y, zs, COL_DIM);
  y += zs * 8 + (SH >= 400 ? 6 : 2);
  int bot = SH - 40;
  if (ix < 0) {
    centreAt(wifiOk ? "no kickoff listed" : "no link yet", y + 4, 2, COL_WHITE);
  } else if (strcmp(view[ix].state, "in") == 0) {
    int room = bot - y;
    if (room < 32) room = 32;
    int z = textFit("ON NOW", SW - 16, room / 2, SH >= 400 ? 8 : 4);
    centreAt("ON NOW", y, z, COL_GREEN);
    y += z * 8 + 6;
    int px = SH >= 400 ? 32 : 18;
    if (y + px < bot) {
      drawSide(SW / 4 - px, y, view[ix].away, view[ix].aPts, px);
      drawSide(SW / 2 + 8, y, view[ix].home, view[ix].hPts, px);
    }
  } else if (view[ix].start > 100000) {
    int lab = SH >= 400 ? 24 : 14;
    drawRemainBig(view[ix].start, y, bot - lab);
    centreAt(view[ix].detail, bot - lab, SH >= 400 ? 2 : 1, COL_DIM);
  } else {
    centreAt(view[ix].detail, y + 4, 2, COL_WHITE);
  }
  paintChipRow();
}

void drawSky() {
  gfx->fillScreen(COL_BG);
  titleRow("TEMP", false);
    bool tall = SH >= 400;
  gfx->setTextSize(tall ? 3 : 2);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(8, tall ? 48 : 36);
  gfx->print(CITIES[cityIx].name);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(8, tall ? 80 : 58);
  gfx->print("tap next to pick your city");
  if (!skyOk) {
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, tall ? 120 : 80);
    gfx->print(wifiOk ? "waiting on the temp" : "no link yet");
  } else {
    char line[24];
    snprintf(line, sizeof(line), "%.0f %s", skyTemp, useC ? "C" : "F");
    gfx->setTextSize(tall ? 5 : 3);
    gfx->setTextColor(COL_GOLD);
    gfx->setCursor(8, tall ? 110 : 78);
    gfx->print(line);
    gfx->setTextSize(tall ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, tall ? 180 : 120);
    gfx->print(skyWord(skyCode));
    snprintf(line, sizeof(line), "wind %.0f mph", skyWind);
    gfx->setCursor(8, tall ? 210 : 140);
    gfx->print(line);
  }
  int y = skyY();
  gfx->fillRoundRect(8, y, 100, 36, 6, COL_CARD);
  gfx->fillRoundRect(116, y, 100, 36, 6, COL_CARD);
  gfx->fillRoundRect(224, y, 80, 36, 6, COL_CARD);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(28, y + 10);
  gfx->print("PREV");
  gfx->setCursor(136, y + 10);
  gfx->print("NEXT");
  gfx->setCursor(250, y + 10);
  gfx->print(useC ? "C" : "F");
  paintChipRow();
}

void teamBox(int i, int *x, int *y, int *w, int *h) {
  int cols = 8;
  int rows = 4;
  int top = 48;
  int bw = (SW - 16) / cols;
  int bh = (SH - top - 60) / rows;
  *x = 8 + (i % cols) * bw;
  *y = top + (i / cols) * bh;
  *w = bw - 4;
  *h = bh - 4;
}

void drawTeam() {
  gfx->fillScreen(COL_BG);
  titleRow("TEAM", false);
  for (int i = 0; i < N_TEAMS; i++) {
    int x, y, w, h;
    teamBox(i, &x, &y, &w, &h);
    bool on = strcmp(fav, TEAMS[i]) == 0;
    gfx->fillRoundRect(x, y, w, h, 6, on ? COL_GOLD : COL_CARD);
    int tsz = h >= 40 ? 2 : 1;
    gfx->setTextSize(tsz);
    gfx->setTextColor(on ? COL_BG : COL_WHITE);
    int tw = (int)strlen(TEAMS[i]) * 6 * tsz;
    gfx->setCursor(x + (w - tw) / 2, y + (h - 8 * tsz) / 2);
    gfx->print(TEAMS[i]);
  }
  paintChipRow();
}

void addKey(int x, int y, int w, int h, int code, const char *s) {
  gfx->fillRoundRect(x, y, w, h, 4, COL_CARD);
  gfx->setTextSize(SH >= 400 ? 2 : 1);
  gfx->setTextColor(COL_WHITE);
  int tw = (int)strlen(s) * 6 * (SH >= 400 ? 2 : 1);
  gfx->setCursor(x + (w - tw) / 2, y + (h - 8 * (SH >= 400 ? 2 : 1)) / 2);
  gfx->print(s);
  if (nKeys < 48) {
    keys[nKeys].x = (int16_t)x;
    keys[nKeys].y = (int16_t)y;
    keys[nKeys].w = (int16_t)w;
    keys[nKeys].h = (int16_t)h;
    keys[nKeys].code = (int16_t)code;
    nKeys++;
  }
}

void drawKeyRows(int y, int kh) {
  const char *r1 = keysNum ? "1234567890" : "qwertyuiop";
  const char *r2 = keysNum ? "-_.:@#+=/" : "asdfghjkl";
  const char *r3 = keysNum ? "()!?'" : "zxcvbnm";
  int gap = 4;
  int w1 = (SW - 8 - 9 * gap) / 10;
  for (int i = 0; r1[i]; i++) {
    char lab[2] = {r1[i], 0};
    addKey(4 + i * (w1 + gap), y, w1, kh - 2, r1[i], lab);
  }
  int n2 = (int)strlen(r2);
  int w2 = w1;
  int x2 = (SW - (n2 * w2 + (n2 - 1) * gap)) / 2;
  for (int i = 0; i < n2; i++) {
    char lab[2] = {r2[i], 0};
    addKey(x2 + i * (w2 + gap), y + kh, w2, kh - 2, r2[i], lab);
  }
  int n3 = (int)strlen(r3);
  for (int i = 0; i < n3; i++) {
    char lab[2] = {r3[i], 0};
    addKey(4 + i * (w1 + gap), y + kh * 2, w1, kh - 2, r3[i], lab);
  }
  addKey(4 + n3 * (w1 + gap), y + kh * 2, w1 * 2, kh - 2, 8, "DEL");
  addKey(4, y + kh * 3, 80, kh - 2, 1, "123");
  addKey(90, y + kh * 3, SW - 180, kh - 2, ' ', "SPACE");
}

void wifiGeom(int *scanY, int *ssidY, int *passY, int *keyY, int *actY, int *kh, int *fieldH) {
  if (SH >= 400) {
    *scanY = 40;
    *ssidY = 96;
    *passY = 146;
    *keyY = 210;
    *actY = 400;
    *kh = 34;
    *fieldH = 40;
  } else {
    *scanY = 22;
    *ssidY = 44;
    *passY = 68;
    *keyY = 94;
    *actY = 196;
    *kh = 22;
    *fieldH = 22;
  }
}

void drawWifi() {
  nKeys = 0;
  int scanY, ssidY, passY, keyY, actY, kh, fieldH;
  wifiGeom(&scanY, &ssidY, &passY, &keyY, &actY, &kh, &fieldH);
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, 4);
  gfx->print("WIFI");
  int nShow = SW >= 700 ? 4 : 2;
  gfx->setTextSize(1);
  gfx->setTextColor(COL_DIM);
  if (SH >= 400) {
    gfx->setCursor(8, scanY - 12);
    gfx->print(nScan ? "tap a network" : "scanning");
  }
  int sw = (SW - 16) / nShow;
  int shBtn = SH >= 400 ? 28 : 18;
  for (int i = 0; i < nScan && i < nShow; i++) {
    gfx->fillRoundRect(8 + i * sw, scanY, sw - 4, shBtn, 4, COL_CARD);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(12 + i * sw, scanY + 4);
    gfx->print(scanName[i]);
  }
  gfx->fillRoundRect(8, ssidY, SW - 16, fieldH, 6, COL_CARD);
  gfx->drawRoundRect(8, ssidY, SW - 16, fieldH, 6, wifiFocus == 0 ? COL_GOLD : COL_LINE);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(12, ssidY + 4);
  if (fieldH > 30) gfx->print("name");
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(fieldH > 30 ? 16 : 52, ssidY + (fieldH > 30 ? 18 : 6));
  gfx->print(wifiSsid);
  gfx->fillRoundRect(8, passY, SW - 16, fieldH, 6, COL_CARD);
  gfx->drawRoundRect(8, passY, SW - 16, fieldH, 6, wifiFocus == 1 ? COL_GOLD : COL_LINE);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(12, passY + 4);
  if (fieldH > 30) gfx->print("password");
  else gfx->print("pw");
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(fieldH > 30 ? 16 : 36, passY + (fieldH > 30 ? 18 : 6));
  gfx->print(wifiPass);
  drawKeyRows(keyY, kh);
  int bw = (SW - 20) / 4;
  int ah = SH >= 400 ? 40 : 28;
  const char *acts[] = {"JOIN", "FORGET", "BACK", "RESET"};
  for (int i = 0; i < 4; i++) {
    int x = 4 + i * (bw + 4);
    gfx->fillRoundRect(x, actY, bw, ah, 6, i == 0 ? COL_GOLD : COL_CARD);
    gfx->setTextSize(SH >= 400 ? 2 : 1);
    gfx->setTextColor(i == 0 ? COL_BG : COL_WHITE);
    int tw = (int)strlen(acts[i]) * 6 * (SH >= 400 ? 2 : 1);
    gfx->setCursor(x + (bw - tw) / 2, actY + (ah - 8 * (SH >= 400 ? 2 : 1)) / 2);
    gfx->print(acts[i]);
  }
}

void typeKey(int code) {
  char *buf = wifiFocus == 0 ? wifiSsid : wifiPass;
  int cap = wifiFocus == 0 ? (int)sizeof(wifiSsid) : (int)sizeof(wifiPass);
  int n = (int)strlen(buf);
  if (code == 8) {
    if (n > 0) buf[n - 1] = 0;
  } else if (code == 1) {
    keysNum = !keysNum;
  } else if (code >= 32 && code < 127 && n < cap - 1) {
    buf[n] = (char)code;
    buf[n + 1] = 0;
  }
  drawWifi();
}

void startScan() {
  scanWait = true;
  nScan = 0;
  WiFi.mode(WIFI_STA);
  WiFi.scanNetworks(true);
}

void joinWifi() {
  savePrefs();
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.disconnect();
  delay(100);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) delay(50);
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (wifiOk) {
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    applyTz();
    page = PG_BOARD;
    lastGames = 0;
    drawBoard();
  } else drawWifi();
}

void updBox() {
  updBh = SH >= 400 ? 48 : 30;
  updBw = SH >= 400 ? 360 : 220;
  updX = (SW - updBw) / 2;
  updY1 = SH >= 400 ? 150 : 72;
  updY2 = updY1 + updBh + (SH >= 400 ? 14 : 8);
}

void drawUpd() {
  updBox();
  gfx->fillScreen(COL_BG);
  titleRow("UPDATE", false);
  char line[48];
  snprintf(line, sizeof(line), "version  %s", KICK_VER);
  centreAt(line, SH >= 400 ? 46 : 34, SH >= 400 ? 2 : 1, COL_WHITE);
  gfx->fillRoundRect(updX, updY1, updBw, updBh, 6, COL_CARD);
  gfx->fillRoundRect(updX, updY2, updBw, updBh, 6, otaNewer ? COL_GOLD : COL_CARD);
  int ts = SH >= 400 ? 2 : 1;
  gfx->setTextSize(ts);
  gfx->setTextColor(COL_WHITE);
  int tw = 5 * 6 * ts;
  gfx->setCursor(updX + (updBw - tw) / 2, updY1 + (updBh - 8 * ts) / 2);
  gfx->print("CHECK");
  gfx->setTextColor(otaNewer ? COL_BG : COL_WHITE);
  tw = 7 * 6 * ts;
  gfx->setCursor(updX + (updBw - tw) / 2, updY2 + (updBh - 8 * ts) / 2);
  gfx->print("INSTALL");
  int my = updY2 + updBh + (SH >= 400 ? 16 : 6);
  centreAt(otaMsg[0] ? otaMsg : "check for updates", my, SH >= 400 ? 2 : 1, COL_DIM);
  if (otaPct >= 0) {
    int bw = SW - 40;
    int bh = SH >= 400 ? 18 : 10;
    int by = SH - (SH >= 400 ? 70 : 50);
    gfx->drawRect(20, by, bw, bh, COL_DIM);
    int w = (bw * (otaPct > 100 ? 100 : otaPct)) / 100;
    if (w > 0) gfx->fillRect(20, by, w, bh, COL_GOLD);
  }
  snprintf(line, sizeof(line), "loads %s", KICK_BIN);
  centreAt(line, SH - (SH >= 400 ? 88 : 62), 1, COL_DIM);
  paintChipRow();
}

int verPack(const char *s) {
  if (!s || !s[0]) return 0;
  int a = 0, b = 0;
  while (*s && !isdigit((unsigned char)*s)) s++;
  while (*s && isdigit((unsigned char)*s)) a = a * 10 + (*s++ - '0');
  if (*s == '.') s++;
  while (*s && isdigit((unsigned char)*s)) b = b * 10 + (*s++ - '0');
  return a * 100 + b;
}

void trimWord(char *s) {
  if (!s) return;
  char *a = s;
  while (*a && isspace((unsigned char)*a)) a++;
  char *e = a + strlen(a);
  while (e > a && isspace((unsigned char)e[-1])) e--;
  *e = 0;
  if (a != s) memmove(s, a, (size_t)(e - a) + 1);
}

void otaNote(const char *s) {
  strlcpy(otaMsg, s ? s : "", sizeof(otaMsg));
  otaRev++;
}

void otaUrl(char *url, int cap, const char *file) {
  snprintf(url, cap, "https://raw.githubusercontent.com/%s/%s/main/ota/%s", KICK_GH_USER, KICK_GH_REPO, file);
}

bool httpText(const char *url, char *body, int cap) {
  body[0] = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(20000);
  http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, url)) return false;
  int code = http.GET();
  if (code == 200) {
    WiFiClient *stream = http.getStreamPtr();
    int got = 0;
    uint32_t t0 = millis();
    while (got < cap - 1 && millis() - t0 < 15000) {
      int a = stream->available();
      if (a <= 0) {
        if (!http.connected()) break;
        delay(2);
        continue;
      }
      if (a > cap - 1 - got) a = cap - 1 - got;
      int r = stream->read((uint8_t *)body + got, a);
      if (r <= 0) break;
      got += r;
    }
    body[got] = 0;
  }
  http.end();
  cli.stop();
  return code == 200 && body[0];
}

void otaCheck() {
  otaNewer = 0;
  otaLatest[0] = 0;
  if (WiFi.status() != WL_CONNECTED) {
    otaNote("join wifi first");
    return;
  }
  char url[140];
  otaUrl(url, sizeof(url), "version.txt");
  char body[48];
  if (!httpText(url, body, sizeof(body))) {
    otaNote("could not reach github");
    return;
  }
  trimWord(body);
  if (!body[0] || strlen(body) > 10) {
    otaNote("bad version file");
    return;
  }
  strlcpy(otaLatest, body, sizeof(otaLatest));
  if (verPack(otaLatest) > verPack(KICK_VER)) {
    otaNewer = 1;
    char msg[48];
    snprintf(msg, sizeof(msg), "version %s  tap INSTALL", otaLatest);
    otaNote(msg);
  } else {
    otaNote("newest firmware already installed");
  }
}

void otaFlash() {
  if (WiFi.status() != WL_CONNECTED) {
    otaNote("join wifi first");
    return;
  }
  if (!otaNewer) {
    otaNote("check first");
    return;
  }
  if (!esp_ota_get_next_update_partition(NULL)) {
    otaNote("no update slot");
    return;
  }
  otaNote("downloading  do not unplug");
  otaPct = 0;
  otaRev++;
  char url[140];
  otaUrl(url, sizeof(url), KICK_BIN);
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
  http.setTimeout(180000);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, url)) {
    otaNote("download fail");
    return;
  }
  int code = http.GET();
  int len = http.getSize();
  if (code != 200 || len < 100000) {
    http.end();
    otaNote(code != 200 ? "download fail" : "file too small");
    return;
  }
  if (!Update.begin((size_t)len)) {
    http.end();
    otaNote("flash begin fail");
    return;
  }
  WiFiClient *stream = http.getStreamPtr();
  size_t got = 0;
  uint8_t buf[1024];
  while (got < (size_t)len) {
    int n = stream->readBytes(buf, sizeof(buf));
    if (n <= 0) {
      if (!http.connected()) break;
      delay(2);
      continue;
    }
    if (Update.write(buf, (size_t)n) != (size_t)n) {
      Update.abort();
      http.end();
      otaNote("flash write fail");
      return;
    }
    got += (size_t)n;
    int p = (int)((got * 100UL) / (size_t)len);
    if (p != otaPct) {
      otaPct = p;
      otaRev++;
    }
  }
  http.end();
  if (got != (size_t)len || !Update.end(true)) {
    otaNote("download fail");
    return;
  }
  otaPct = 100;
  otaNote("done  rebooting");
  delay(800);
  ESP.restart();
}

void runOtaJob() {
  if (otaKind == 1) otaCheck();
  else if (otaKind == 2) otaFlash();
  otaKind = 0;
  otaBusy = 0;
  otaRev++;
}

void askOta(int kind) {
  if (otaBusy || job != 0) {
    otaNote("busy");
    return;
  }
  otaKind = kind;
  otaPct = kind == 2 ? 0 : -1;
  otaNote(kind == 1 ? "checking" : "starting update");
  otaBusy = 1;
  job = 3;
}

void tapUpd(int x, int y) {
  if (otaBusy) return;
  updBox();
  if (hit(x, y, updX, updY1, updX + updBw, updY1 + updBh)) askOta(1);
  else if (hit(x, y, updX, updY2, updX + updBw, updY2 + updBh)) askOta(2);
}

void redraw() {
  if (page == PG_BOARD) drawBoard();
  else if (page == PG_NEXT) drawNext();
  else if (page == PG_SKY) drawSky();
  else if (page == PG_TEAM) drawTeam();
  else if (page == PG_WIFI) drawWifi();
  else drawUpd();
}

void cycleTz() {
  tzIx = (tzIx + 1) % 4;
  applyTz();
  savePrefs();
  shownMin = -1;
  redraw();
}

void tapBoard(int x, int y) {
  Kick view[16];
  int n = copyGames(view);
  if (scrollOn(n)) {
    int vis = boardRows() * boardCols();
    if (hit(x, y, SW - 156, 14, SW - 86, 42)) {
      if (gTop >= vis) gTop -= vis;
      drawBoard();
      return;
    }
    if (hit(x, y, SW - 78, 14, SW - 8, 42)) {
      if (gTop + vis < n) gTop += vis;
      drawBoard();
      return;
    }
  }
  if (hit(x, y, clockX(scrollOn(n)), 12, clockX(scrollOn(n)) + 160, 44)) cycleTz();
}

int skyY() { return SH >= 400 ? 360 : 176; }

void tapSky(int x, int y) {
  if (hit(x, y, clockX(false), 12, clockX(false) + 170, 44)) {
    cycleTz();
    return;
  }
  int yb = skyY();
  if (hit(x, y, 8, yb, 108, yb + 36)) {
    cityIx = (cityIx + N_CITIES - 1) % N_CITIES;
    skyOk = false;
    savePrefs();
    drawSky();
    if (wifiOk && !busy) {
      busy = true;
      job = 2;
    }
    return;
  }
  if (hit(x, y, 116, yb, 216, yb + 36)) {
    cityIx = (cityIx + 1) % N_CITIES;
    skyOk = false;
    savePrefs();
    drawSky();
    if (wifiOk && !busy) {
      busy = true;
      job = 2;
    }
    return;
  }
  if (hit(x, y, 224, yb, 304, yb + 36)) {
    useC = !useC;
    skyOk = false;
    savePrefs();
    drawSky();
    if (wifiOk && !busy) {
      busy = true;
      job = 2;
    }
  }
}

void tapTeam(int x, int y) {
  if (hit(x, y, clockX(false), 12, clockX(false) + 170, 44)) {
    cycleTz();
    return;
  }
  for (int i = 0; i < N_TEAMS; i++) {
    int bx, by, bw, bh;
    teamBox(i, &bx, &by, &bw, &bh);
    if (hit(x, y, bx, by, bx + bw, by + bh)) {
      if (strcmp(fav, TEAMS[i]) == 0) fav[0] = 0;
      else strlcpy(fav, TEAMS[i], sizeof(fav));
      savePrefs();
      drawTeam();
      return;
    }
  }
}

void tapWifi(int x, int y) {
  int scanY, ssidY, passY, keyY, actY, kh, fieldH;
  wifiGeom(&scanY, &ssidY, &passY, &keyY, &actY, &kh, &fieldH);
  int nShow = SW >= 700 ? 4 : 2;
  int sw = (SW - 16) / nShow;
  (void)keyY;
  (void)kh;
  for (int i = 0; i < nScan && i < nShow; i++) {
    int shBtn = SH >= 400 ? 28 : 18;
    if (hit(x, y, 8 + i * sw, scanY, 8 + i * sw + sw - 4, scanY + shBtn)) {
      strlcpy(wifiSsid, scanName[i], sizeof(wifiSsid));
      wifiFocus = 1;
      drawWifi();
      return;
    }
  }
  if (hit(x, y, 8, ssidY, SW - 8, ssidY + fieldH)) {
    wifiFocus = 0;
    drawWifi();
    return;
  }
  if (hit(x, y, 8, passY, SW - 8, passY + fieldH)) {
    wifiFocus = 1;
    drawWifi();
    return;
  }
  for (int i = 0; i < nKeys; i++) {
    if (hit(x, y, keys[i].x, keys[i].y, keys[i].x + keys[i].w, keys[i].y + keys[i].h)) {
      typeKey(keys[i].code);
      return;
    }
  }
  int bw = (SW - 20) / 4;
  int ah = SH >= 400 ? 40 : 28;
  if (hit(x, y, 4, actY, 4 + bw, actY + ah)) {
    joinWifi();
    return;
  }
  if (hit(x, y, 4 + (bw + 4), actY, 4 + (bw + 4) + bw, actY + ah)) {
    wifiSsid[0] = wifiPass[0] = 0;
    savePrefs();
    WiFi.disconnect(true, true);
    drawWifi();
    return;
  }
  if (hit(x, y, 4 + 2 * (bw + 4), actY, 4 + 2 * (bw + 4) + bw, actY + ah)) {
    page = PG_BOARD;
    drawBoard();
    return;
  }
  if (hit(x, y, 4 + 3 * (bw + 4), actY, 4 + 3 * (bw + 4) + bw, actY + ah)) {
    prefs.begin(PREF_NS, false);
    prefs.clear();
    prefs.end();
    delay(100);
    ESP.restart();
  }
}

void onTap(int x, int y) {
  if (page != PG_WIFI) {
    for (int i = 0; i < 6; i++) {
      if (chipHit(x, y, i)) {
        if (i == PG_WIFI) {
          page = PG_WIFI;
          startScan();
          drawWifi();
        } else {
          page = i;
          redraw();
          if (page == PG_SKY && wifiOk && !busy) {
            busy = true;
            job = 2;
          }
        }
        return;
      }
    }
  }
  if (page == PG_BOARD) tapBoard(x, y);
  else if (page == PG_NEXT) {
    if (hit(x, y, clockX(false), 0, SW - 4, 32) ||
        hit(x, y, bigX - 8, bigY - 4, bigX + bigW + 8, bigY + bigH + 4))
      cycleTz();
  } else if (page == PG_UPD) tapUpd(x, y);
  else if (page == PG_SKY) tapSky(x, y);
  else if (page == PG_TEAM) tapTeam(x, y);
  else tapWifi(x, y);
}

bool anyLive() {
  Kick view[16];
  int n = copyGames(view);
  for (int i = 0; i < n; i++)
    if (strcmp(view[i].state, "in") == 0) return true;
  return false;
}

void connectWifi() {
  loadPrefs();
  if (!wifiSsid[0]) {
    page = PG_WIFI;
    startScan();
    drawWifi();
    return;
  }
  page = PG_BOARD;
  gfx->fillScreen(COL_BG);
  gfx->setTextColor(COL_WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(8, 80);
  gfx->print("linking");
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(50);
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (wifiOk) {
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    applyTz();
  }
  drawBoard();
}

void pollScan() {
  if (!scanWait || page != PG_WIFI) return;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return;
  scanWait = false;
  if (n < 0) return;
  nScan = n > 4 ? 4 : n;
  for (int i = 0; i < nScan; i++) strlcpy(scanName[i], WiFi.SSID(i).c_str(), sizeof(scanName[i]));
  WiFi.scanDelete();
  drawWifi();
}

void setup() {
  Serial.begin(115200);
  boardIoBegin();
  rgbBus = new Arduino_ESP32RGBPanel(
      5, 3, 46, 7,
      1, 2, 42, 41, 40,
      39, 0, 45, 48, 47, 21,
      14, 38, 18, 17, 10,
      0, 8, 4, 8,
      0, 8, 4, 8,
      1, 12500000, false, 0, 0, 800 * 20);
  gfx = new Arduino_RGB_Display(SW, SH, rgbBus, 0, true);
  if (!gfx->begin()) {
    Serial.println("gfx begin failed");
    return;
  }
  gfx->setTextWrap(false);
  ch422Bit(EXIO_LCD_BL, true);
  gameLock = xSemaphoreCreateMutex();
  xTaskCreatePinnedToCore(netTask, "kicknet", 40960, nullptr, 1, nullptr, 0);
  connectWifi();
  lastTap = millis();
  redraw();
  shownAt = millis();
}

void loop() {
  if (page == PG_UPD && otaRev != shownRev) {
    shownRev = otaRev;
    drawUpd();
  }
  if (otaBusy) {
    delay(8);
    return;
  }
  if (shownAt && millis() - shownAt > 700) {
    shownAt = 0;
    redraw();
  }
  pollScan();
  int x, y;
  if (readFinger(&x, &y) == 1 && millis() - lastTap > 180) {
    lastTap = millis();
    onTap(x, y);
  }
  if (dirty && !busy) {
    dirty = false;
    if (page != PG_WIFI) redraw();
  }
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (!busy && !otaBusy && wifiOk && page != PG_WIFI && page != PG_UPD) {
    uint32_t nowMs = millis();
    uint32_t gap = anyLive() ? 45000UL : 180000UL;
    if ((page == PG_BOARD || page == PG_NEXT) && (lastGames == 0 || nowMs - lastGames > gap)) {
      busy = true;
      job = 1;
    } else if (page == PG_SKY && (lastSky == 0 || nowMs - lastSky > 600000UL)) {
      busy = true;
      job = 2;
    }
  }
  if (page != PG_WIFI) {
    time_t now = time(nullptr);
    if (now > 100000) {
      struct tm t;
      localtime_r(&now, &t);
      int minute = t.tm_hour * 60 + t.tm_min;
      if (minute != shownMin) {
        shownMin = minute;
        redraw();
      }
    }
  }
  delay(8);
}
