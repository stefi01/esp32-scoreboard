/*
  Kickoff desk — Freenove FNK0115B, 4.3 inch, 480x272.
  Pro games, a countdown to the next kickoff, a favorite team,
  and a temperature card for a city you pick. Prefs name kick43.
  Arduino: ESP32S3 Dev Module, PSRAM OPI PSRAM, Flash 16MB,
  USB CDC On Boot Enabled.
  Screen clock 9000000, bounce 272 * 40. Touch map matches the 4.3 weather desk.
*/

#include <Arduino_GFX_Library.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <EEPROM.h>
#include <SPI.h>
#include "esp_heap_caps.h"
#include "XPT2046_Touchscreen.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <Update.h>
#include "esp_ota_ops.h"
#include "team_marks.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define SW 480
#define SH 272
#define PREF_NS "kick43"
#define GFX_BL 2
#define PIN_DE 40
#define PIN_VSYNC 41
#define PIN_HSYNC 39
#define PIN_PCLK 42
#define TOUCH_SCK 12
#define TOUCH_MISO 13
#define TOUCH_MOSI 11
#define TOUCH_CS 38
#define TOUCH_IRQ 18

#define KICK_VER "1.0"
#define KICK_GH_USER "stefi01"
#define KICK_GH_REPO "esp32-scoreboard"
#define KICK_BIN "kick_43.bin"
enum { PG_BOARD = 0, PG_NEXT, PG_SKY, PG_TEAM, PG_WIFI, PG_UPD, PG_SEASON, PG_TODAY, PG_WEEK };

struct Kick {
  char name[20];
  char away[4];
  char home[4];
  char detail[36];
  char score[16];
  char aPts[6];
  char hPts[6];
  char state[8];
  time_t start;
};

struct SeasonRow {
  char ab[4];
  uint8_t w, l, t;
};

struct SeasonBlob {
  uint16_t magic;
  uint16_t year;
  uint8_t n;
  SeasonRow row[32];
};

struct City {
  const char *name;
  float lat, lon;
};

struct Key {
  int16_t x, y, w, h, code;
};

const City CITIES[] = {
    {"Fresno", 36.7378f, -119.7871f},
    {"Los Angeles", 34.0522f, -118.2437f},
    {"San Diego", 32.7157f, -117.1611f},
    {"San Francisco", 37.7749f, -122.4194f},
    {"Sacramento", 38.5816f, -121.4944f},
    {"Seattle", 47.6062f, -122.3321f},
    {"Portland", 45.5152f, -122.6784f},
    {"Phoenix", 33.4484f, -112.0740f},
    {"Las Vegas", 36.1699f, -115.1398f},
    {"Denver", 39.7392f, -104.9903f},
    {"Salt Lake City", 40.7608f, -111.8910f},
    {"Albuquerque", 35.0844f, -106.6504f},
    {"Dallas", 32.7767f, -96.7970f},
    {"Houston", 29.7604f, -95.3698f},
    {"Kansas City", 39.0997f, -94.5786f},
    {"Minneapolis", 44.9778f, -93.2650f},
    {"Chicago", 41.8781f, -87.6298f},
    {"Green Bay", 44.5133f, -88.0133f},
    {"Detroit", 42.3314f, -83.0458f},
    {"Atlanta", 33.7490f, -84.3880f},
    {"Miami", 25.7617f, -80.1918f},
    {"New Orleans", 29.9511f, -90.0715f},
    {"Nashville", 36.1627f, -86.7816f},
    {"St Louis", 38.6270f, -90.1994f},
    {"Boston", 42.3601f, -71.0589f},
    {"New York", 40.7128f, -74.0060f},
    {"Philadelphia", 39.9526f, -75.1652f},
    {"Washington", 38.9072f, -77.0369f},
    {"Charlotte", 35.2271f, -80.8431f},
    {"Anchorage", 61.2181f, -149.9003f},
    {"Honolulu", 21.3069f, -157.8583f},
    {"San Jose", 37.3382f, -121.8863f},
    {"Oakland", 37.8044f, -122.2712f},
    {"Bakersfield", 35.3733f, -119.0187f},
    {"Long Beach", 33.7701f, -118.1937f},
    {"Tucson", 32.2226f, -110.9747f},
    {"Flagstaff", 35.1983f, -111.6513f},
    {"Reno", 39.5296f, -119.8138f},
    {"Henderson", 36.0395f, -114.9817f},
    {"Spokane", 47.6588f, -117.4260f},
    {"Tacoma", 47.2529f, -122.4443f},
    {"Eugene", 44.0521f, -123.0868f},
    {"Salem", 44.9429f, -123.0351f},
    {"Bend", 44.0582f, -121.3153f},
    {"Boise", 43.6150f, -116.2023f},
    {"Idaho Falls", 43.4917f, -112.0339f},
    {"Colorado Springs", 38.8339f, -104.8214f},
    {"Boulder", 40.0150f, -105.2705f},
    {"Provo", 40.2338f, -111.6585f},
    {"Ogden", 41.2230f, -111.9738f},
    {"Santa Fe", 35.6870f, -105.9378f},
    {"Las Cruces", 32.3199f, -106.7637f},
    {"Billings", 45.7833f, -108.5007f},
    {"Missoula", 46.8721f, -113.9940f},
    {"Helena", 46.5891f, -112.0391f},
    {"Cheyenne", 41.1400f, -104.8202f},
    {"Casper", 42.8666f, -106.3131f},
    {"Austin", 30.2672f, -97.7431f},
    {"San Antonio", 29.4241f, -98.4936f},
    {"Fort Worth", 32.7555f, -97.3308f},
    {"El Paso", 31.7619f, -106.4850f},
    {"Lubbock", 33.5779f, -101.8552f},
    {"Corpus Christi", 27.8006f, -97.3964f},
    {"Oklahoma City", 35.4676f, -97.5164f},
    {"Tulsa", 36.1540f, -95.9928f},
    {"Wichita", 37.6872f, -97.3301f},
    {"Topeka", 39.0473f, -95.6752f},
    {"Omaha", 41.2565f, -95.9345f},
    {"Lincoln", 40.8136f, -96.7026f},
    {"Des Moines", 41.5868f, -93.6250f},
    {"Cedar Rapids", 41.9779f, -91.6656f},
    {"Sioux Falls", 43.5460f, -96.7313f},
    {"Rapid City", 44.0805f, -103.2310f},
    {"Fargo", 46.8772f, -96.7898f},
    {"Bismarck", 46.8083f, -100.7837f},
    {"Little Rock", 34.7465f, -92.2896f},
    {"Fayetteville", 36.0626f, -94.1574f},
    {"Indianapolis", 39.7684f, -86.1581f},
    {"Fort Wayne", 41.0793f, -85.1394f},
    {"South Bend", 41.6764f, -86.2520f},
    {"Columbus", 39.9612f, -82.9988f},
    {"Cleveland", 41.4993f, -81.6944f},
    {"Cincinnati", 39.1031f, -84.5120f},
    {"Toledo", 41.6528f, -83.5379f},
    {"Dayton", 39.7589f, -84.1916f},
    {"Milwaukee", 43.0389f, -87.9065f},
    {"Madison", 43.0731f, -89.4012f},
    {"Grand Rapids", 42.9634f, -85.6681f},
    {"Lansing", 42.7325f, -84.5555f},
    {"Ann Arbor", 42.2808f, -83.7430f},
    {"Springfield", 39.7817f, -89.6501f},
    {"Rockford", 42.2711f, -89.0940f},
    {"Peoria", 40.6936f, -89.5890f},
    {"St Paul", 44.9537f, -93.0900f},
    {"Duluth", 46.7867f, -92.1005f},
    {"Rochester MN", 44.0121f, -92.4802f},
    {"Louisville", 38.2527f, -85.7585f},
    {"Lexington", 38.0406f, -84.5037f},
    {"Springfield MO", 37.2090f, -93.2923f},
    {"Columbia MO", 38.9517f, -92.3341f},
    {"Memphis", 35.1495f, -90.0490f},
    {"Knoxville", 35.9606f, -83.9207f},
    {"Chattanooga", 35.0456f, -85.3097f},
    {"Birmingham", 33.5207f, -86.8025f},
    {"Mobile", 30.6954f, -88.0399f},
    {"Montgomery", 32.3792f, -86.3077f},
    {"Jackson", 32.2988f, -90.1848f},
    {"Gulfport", 30.3674f, -89.0928f},
    {"Baton Rouge", 30.4515f, -91.1871f},
    {"Shreveport", 32.5252f, -93.7502f},
    {"Tampa", 27.9506f, -82.4572f},
    {"Orlando", 28.5383f, -81.3792f},
    {"Jacksonville", 30.3322f, -81.6557f},
    {"Tallahassee", 30.4383f, -84.2807f},
    {"Savannah", 32.0809f, -81.0912f},
    {"Augusta", 33.4735f, -82.0105f},
    {"Raleigh", 35.7796f, -78.6382f},
    {"Greensboro", 36.0726f, -79.7920f},
    {"Asheville", 35.5951f, -82.5515f},
    {"Charleston", 32.7765f, -79.9311f},
    {"Columbia", 34.0007f, -81.0348f},
    {"Greenville", 34.8526f, -82.3940f},
    {"Richmond", 37.5407f, -77.4360f},
    {"Virginia Beach", 36.8529f, -75.9780f},
    {"Norfolk", 36.8508f, -76.2859f},
    {"Roanoke", 37.2710f, -79.9414f},
    {"Baltimore", 39.2904f, -76.6122f},
    {"Annapolis", 38.9784f, -76.4922f},
    {"Charleston WV", 38.3498f, -81.6326f},
    {"Huntington", 38.4192f, -82.4452f},
    {"Pittsburgh", 40.4406f, -79.9959f},
    {"Harrisburg", 40.2732f, -76.8867f},
    {"Allentown", 40.6084f, -75.4902f},
    {"Buffalo", 42.8864f, -78.8784f},
    {"Rochester", 43.1566f, -77.6088f},
    {"Albany", 42.6526f, -73.7562f},
    {"Syracuse", 43.0481f, -76.1474f},
    {"Newark", 40.7357f, -74.1724f},
    {"Jersey City", 40.7178f, -74.0431f},
    {"Trenton", 40.2204f, -74.7699f},
    {"Atlantic City", 39.3643f, -74.4229f},
    {"Hartford", 41.7658f, -72.6734f},
    {"New Haven", 41.3083f, -72.9279f},
    {"Bridgeport", 41.1865f, -73.1952f},
    {"Providence", 41.8240f, -71.4128f},
    {"Worcester", 42.2626f, -71.8023f},
    {"Springfield MA", 42.1015f, -72.5898f},
    {"Manchester", 42.9956f, -71.4548f},
    {"Concord", 43.2081f, -71.5376f},
    {"Portland ME", 43.6591f, -70.2568f},
    {"Bangor", 44.8016f, -68.7712f},
    {"Burlington", 44.4759f, -73.2121f},
    {"Wilmington", 39.7391f, -75.5398f},
    {"Dover", 39.1582f, -75.5244f},
    {"Fairbanks", 64.8378f, -147.7164f},
    {"Juneau", 58.3019f, -134.4197f},
};
const int N_CITIES = sizeof(CITIES) / sizeof(CITIES[0]);

const char *TEAMS[] = {
    "ARI", "ATL", "BAL", "BUF", "CAR", "CHI", "CIN", "CLE",
    "DAL", "DEN", "DET", "GB",  "HOU", "IND", "JAX", "KC",
    "LAC", "LAR", "LV",  "MIA", "MIN", "NE",  "NO",  "NYG",
    "NYJ", "PHI", "PIT", "SEA", "SF",  "TB",  "TEN", "WAS",
};
const int N_TEAMS = 32;

const char *TZS[] = {
    "PST8PDT,M3.2.0,M11.1.0",
    "MST7MDT,M3.2.0,M11.1.0",
    "CST6CDT,M3.2.0,M11.1.0",
    "EST5EDT,M3.2.0,M11.1.0",
};
const char *TZLAB[] = {"Pacific", "Mountain", "Central", "Eastern"};

const uint16_t COL_BG = 0x0841;
const uint16_t COL_CARD = 0x2124;
const uint16_t COL_GOLD = 0xFE60;
const uint16_t COL_WHITE = 0xFFFF;
const uint16_t COL_DIM = 0xBDF7;
const uint16_t COL_GREEN = 0x07E0;
const uint16_t COL_LINE = 0x4208;

Arduino_ESP32RGBPanel *rgbBus = nullptr;
Arduino_GFX *gfx = nullptr;
Preferences prefs;
XPT2046_Touchscreen ts(TOUCH_CS, TOUCH_IRQ);

Kick games[16];
int nGames = 0;
SeasonBlob season;
SemaphoreHandle_t gameLock = nullptr;

char wifiSsid[33];
char wifiPass[65];
char fav[8];
int cityIx = 0;
int tzIx = 0;
bool useC = false;
int page = PG_BOARD;
int gTop = 0;
char focusName[20];
bool wifiOk = false;
bool skyOk = false;
float skyTemp = 0, skyWind = 0;
int skyCode = 0;
int cityOff = 0;
bool cityOffOk = false;
Kick today[16];
int nToday = 0;
int todayYmd = 0;
int todayTop = 0;
Kick soon[24];
int nSoon = 0;
bool shiftFix = false;
int soonTop = 0;
int seasonTop = 0;
char scanName[4][33];
int nScan = 0;
bool scanWait = false;
bool keysNum = false;
int wifiFocus = 0;
Key keys[48];
int nKeys = 0;
volatile int job = 0;
volatile bool busy = false;
volatile bool dirty = false;
uint32_t lastGames = 0;
uint32_t lastSky = 0;
uint32_t lastSeason = 0;
uint32_t lastSoon = 0;
int clkDrawX = 0;
uint32_t lastTap = 0;
uint32_t shownAt = 0;
int shownMin = -1;
int bigX = 0, bigY = 0, bigW = 0, bigH = 0;
char otaMsg[48];
char otaLatest[12];
volatile int otaPct = -1;
volatile int otaBusy = 0;
volatile int otaRev = 0;
int otaNewer = 0;
int otaKind = 0;
int shownRev = 0;
int updX = 0, updY1 = 0, updY2 = 0, updBw = 0, updBh = 0;

bool hit(int x, int y, int x0, int y0, int x1, int y1) {
  return x >= x0 && x < x1 && y >= y0 && y < y1;
}

int readFinger(int *x, int *y) {
  if (!ts.touched()) return 0;
  TS_Point a = ts.getPoint();
  delay(4);
  if (!ts.touched()) return 0;
  TS_Point b = ts.getPoint();
  if (abs(a.x - b.x) > 20 || abs(a.y - b.y) > 20) return 0;
  int px = map(((int)a.x + (int)b.x) / 2, 3800, 170, 0, SW - 1);
  int py = map(((int)a.y + (int)b.y) / 2, 250, 3800, 0, SH - 1);
  *x = constrain(SW - 1 - px, 0, SW - 1);
  *y = constrain(SH - 1 - py, 0, SH - 1);
  return 1;
}

void applyTz() {
  if (tzIx < 0 || tzIx > 3) tzIx = 0;
  setenv("TZ", TZS[tzIx], 1);
  tzset();
}

void savePrefs() {
  prefs.begin(PREF_NS, false);
  prefs.putString("ssid", wifiSsid);
  prefs.putString("pass", wifiPass);
  prefs.putString("fav", fav);
  prefs.putInt("city", cityIx);
  prefs.putInt("tz", tzIx);
  prefs.putBool("c", useC);
  prefs.end();
}

void loadPrefs() {
  wifiSsid[0] = wifiPass[0] = fav[0] = 0;
  prefs.begin(PREF_NS, true);
  prefs.getString("ssid", wifiSsid, sizeof(wifiSsid));
  prefs.getString("pass", wifiPass, sizeof(wifiPass));
  prefs.getString("fav", fav, sizeof(fav));
  cityIx = prefs.getInt("city", 0);
  tzIx = prefs.getInt("tz", 0);
  useC = prefs.getBool("c", false);
  prefs.end();
  if (cityIx < 0 || cityIx >= N_CITIES) cityIx = 0;
  applyTz();
}

bool scoreRose(const Kick *oldg, const Kick *now) {
  if (!oldg->aPts[0] && !oldg->hPts[0]) return false;
  if (atoi(now->aPts) > atoi(oldg->aPts)) return true;
  if (atoi(now->hPts) > atoi(oldg->hPts)) return true;
  return false;
}

int ymdOf(time_t when) {
  if (when < 100000) return 0;
  struct tm t;
  localtime_r(&when, &t);
  return (t.tm_year + 1900) * 10000 + (t.tm_mon + 1) * 100 + t.tm_mday;
}

void rollToday() {
  int ymd = ymdOf(time(nullptr));
  if (!ymd) return;
  if (todayYmd && todayYmd != ymd) nToday = 0;
  todayYmd = ymd;
}

struct EndedMark {
  char name[20];
  time_t at;
};
EndedMark endedMark[16];
int nEnded = 0;

void noteEnded(const char *name) {
  if (!name || !name[0]) return;
  for (int i = 0; i < nEnded; i++)
    if (strcmp(endedMark[i].name, name) == 0) return;
  if (nEnded >= 16) return;
  strlcpy(endedMark[nEnded].name, name, sizeof(endedMark[nEnded].name));
  endedMark[nEnded].at = time(nullptr);
  nEnded++;
}

char heldOff[8][20];
int nHeld = 0;

bool heldOffName(const char *name) {
  if (!name || !name[0]) return false;
  for (int i = 0; i < nHeld; i++)
    if (strcmp(heldOff[i], name) == 0) return true;
  return false;
}

void holdOff(const char *name) {
  if (!name || !name[0] || heldOffName(name) || nHeld >= 8) return;
  strlcpy(heldOff[nHeld], name, sizeof(heldOff[0]));
  nHeld++;
}

bool gameOver(const Kick *g) {
  if (heldOffName(g->name)) return true;
  if (g->start > 100000 && time(nullptr) > g->start + 5 * 3600) return true;
  bool final = strcmp(g->state, "post") == 0 || strncmp(g->detail, "Final", 5) == 0;
  if (strcmp(g->state, "in") == 0 && !final) return false;
  if (final) {
    for (int i = 0; i < nEnded; i++) {
      if (strcmp(endedMark[i].name, g->name) == 0)
        return time(nullptr) >= endedMark[i].at + 5 * 60;
    }
    return true;
  }
  return false;
}

void keepToday(const Kick *g) {
  rollToday();
  int gd = ymdOf(g->start);
  if (gd && todayYmd && gd != todayYmd) return;
  for (int i = 0; i < nToday; i++) {
    if (strcmp(today[i].name, g->name) == 0) {
      today[i] = *g;
      return;
    }
  }
  if (nToday >= 16) return;
  today[nToday++] = *g;
}

void clearPlaying(const char *name) {
  if (!name || !name[0]) return;
  holdOff(name);
  Kick gone;
  bool found = false;
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  int w = 0;
  for (int i = 0; i < nGames; i++) {
    if (!found && strcmp(games[i].name, name) == 0) {
      gone = games[i];
      found = true;
      continue;
    }
    if (w != i) games[w] = games[i];
    w++;
  }
  if (found) nGames = w;
  if (gameLock) xSemaphoreGive(gameLock);
  if (found) keepToday(&gone);
  if (strcmp(focusName, name) == 0) focusName[0] = 0;
}

int pickNext(Kick *view, int n);

void publishGames(Kick *src, int n) {
  if (n < 0) n = 0;
  if (n > 16) n = 16;
  Kick ordered[16];
  if (n > 0) memcpy(ordered, src, sizeof(Kick) * n);
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  if (n > 0) {
    bool scored[16];
    bool anyScore = false;
    for (int i = 0; i < n; i++) scored[i] = false;
    if (nGames > 0) {
      for (int i = 0; i < n; i++) {
        const Kick *oldg = nullptr;
        for (int j = 0; j < nGames; j++) {
          if (strcmp(games[j].name, ordered[i].name) == 0) {
            oldg = &games[j];
            break;
          }
        }
        if (oldg && strcmp(ordered[i].state, "in") == 0 && scoreRose(oldg, &ordered[i])) {
          scored[i] = true;
          anyScore = true;
        }
      }
    }
    int nextIx = pickNext(ordered, n);
    int slot[16];
    int ns = 0;
    for (int i = 0; i < n; i++) {
      if (strcmp(ordered[i].state, "in") == 0 && scored[i]) slot[ns++] = i;
    }
    for (int i = 0; i < n; i++) {
      if (strcmp(ordered[i].state, "in") == 0 && !scored[i]) slot[ns++] = i;
    }
    if (nextIx >= 0 && nextIx < n && strcmp(ordered[nextIx].state, "in") != 0) slot[ns++] = nextIx;
    for (int i = 0; i < n; i++) {
      bool used = false;
      for (int k = 0; k < ns; k++)
        if (slot[k] == i) used = true;
      if (!used) slot[ns++] = i;
    }
    if (ns == n) {
      bool moved = false;
      for (int i = 0; i < n; i++) {
        if (slot[i] != i) moved = true;
      }
      if (moved) {
        Kick tmp[16];
        for (int i = 0; i < n; i++) tmp[i] = ordered[slot[i]];
        memcpy(ordered, tmp, sizeof(Kick) * n);
      }
      if (anyScore || (moved && slot[0] != 0)) gTop = 0;
    }
  }
  rollToday();
  for (int i = 0; i < n; i++) {
    if (strcmp(ordered[i].state, "post") != 0 && strncmp(ordered[i].detail, "Final", 5) != 0) continue;
    for (int j = 0; j < nGames; j++) {
      if (strcmp(games[j].name, ordered[i].name) == 0 && strcmp(games[j].state, "in") == 0) {
        noteEnded(ordered[i].name);
        break;
      }
    }
  }
  int keep = 0;
  for (int i = 0; i < n; i++) {
    if (gameOver(&ordered[i])) keepToday(&ordered[i]);
    else {
      if (keep != i) ordered[keep] = ordered[i];
      keep++;
    }
  }
  n = keep;
  nGames = n;
  if (n > 0) memcpy(games, ordered, sizeof(Kick) * n);
  if (gameLock) xSemaphoreGive(gameLock);
}

int copyGames(Kick *dst) {
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  int n = nGames;
  if (n > 0) memcpy(dst, games, sizeof(Kick) * n);
  if (gameLock) xSemaphoreGive(gameLock);
  return n;
}

bool grab(const char *p, const char *key, char *out, int cap) {
  const char *f = strstr(p, key);
  out[0] = 0;
  if (!f) return false;
  f += strlen(key);
  int i = 0;
  while (f[i] && f[i] != '"' && i < cap - 1) {
    out[i] = f[i];
    i++;
  }
  out[i] = 0;
  return i > 0;
}

time_t utcParts(int y, int mo, int d, int h, int mi) {
  struct tm t;
  memset(&t, 0, sizeof(t));
  t.tm_year = y - 1900;
  t.tm_mon = mo - 1;
  t.tm_mday = d;
  t.tm_hour = h;
  t.tm_min = mi;
  char saved[48];
  const char *cur = getenv("TZ");
  saved[0] = 0;
  if (cur) strlcpy(saved, cur, sizeof(saved));
  setenv("TZ", "UTC0", 1);
  tzset();
  time_t u = mktime(&t);
  if (saved[0]) setenv("TZ", saved, 1);
  else unsetenv("TZ");
  tzset();
  return u;
}

void splitClubs(Kick *g) {
  g->away[0] = 0;
  g->home[0] = 0;
  const char *at = strstr(g->name, " @ ");
  int sep = 3;
  if (!at) {
    at = strstr(g->name, " VS ");
    sep = 4;
  }
  if (!at) return;
  int n = (int)(at - g->name);
  if (n > 3) n = 3;
  if (n < 0) n = 0;
  memcpy(g->away, g->name, (size_t)n);
  g->away[n] = 0;
  strlcpy(g->home, at + sep, sizeof(g->home));
  if (strlen(g->home) > 3) g->home[3] = 0;
}

void clubScore(const char *block, const char *ab, char *out, int cap) {
  out[0] = 0;
  if (!ab || !ab[0]) return;
  char key[28];
  snprintf(key, sizeof(key), "\"abbreviation\":\"%s\"", ab);
  const char *p = block;
  while ((p = strstr(p, key)) != nullptr) {
    const char *from = p - 240;
    if (from < block) from = block;
    bool side = false;
    for (const char *q = from; q + 12 < p + 180; q++) {
      if (strncmp(q, "\"homeAway\":\"", 12) == 0) {
        side = true;
        break;
      }
    }
    if (!side) {
      p += 8;
      continue;
    }
    const char *end = p + 4000;
    const char *nextSide = strstr(p + 16, "\"homeAway\":\"");
    if (nextSide && nextSide < end) end = nextSide;
    const char *sc = strstr(p, "\"score\":\"");
    if (sc && sc < end) grab(sc, "\"score\":\"", out, cap);
    return;
  }
}

bool takeGame(const char *block, const char *win, const char *at, Kick *g) {
  memset(g, 0, sizeof(*g));
  const char *name = block + 13;
  int i = 0;
  while (name[i] && name[i] != '"' && i < (int)sizeof(g->name) - 1) {
    g->name[i] = name[i];
    i++;
  }
  g->name[i] = 0;
  if (!strstr(g->name, " @ ") && !strstr(g->name, " VS ")) return false;
  splitClubs(g);
  grab(block, "\"shortDetail\":\"", g->detail, sizeof(g->detail));
  if (!g->detail[0]) {
    char clk[12];
    clk[0] = 0;
    grab(block, "\"displayClock\":\"", clk, sizeof(clk));
    if (clk[0]) strlcpy(g->detail, clk, sizeof(g->detail));
  }
  g->state[0] = 0;
  const char *sp = block;
  while ((sp = strstr(sp, "\"state\":\"")) != nullptr) {
    sp += 9;
    if (strncmp(sp, "pre\"", 4) == 0 || strncmp(sp, "in\"", 3) == 0 || strncmp(sp, "post\"", 5) == 0) {
      int k = 0;
      while (sp[k] && sp[k] != '"' && k < (int)sizeof(g->state) - 1) {
        g->state[k] = sp[k];
        k++;
      }
      g->state[k] = 0;
      break;
    }
  }
  if (strcmp(g->state, "pre") != 0) {
    clubScore(block, g->away, g->aPts, sizeof(g->aPts));
    clubScore(block, g->home, g->hPts, sizeof(g->hPts));
  }
  if (g->aPts[0] && g->hPts[0])
    snprintf(g->score, sizeof(g->score), "%s-%s", g->aPts, g->hPts);
  char *from = (char *)at - 500;
  if (from < win) from = (char *)win;
  for (char *q = (char *)at; q >= from; q--) {
    if (strncmp(q, "\"date\":\"", 8) == 0) {
      int y, mo, d, h, mi;
      if (sscanf(q + 8, "%d-%d-%dT%d:%d", &y, &mo, &d, &h, &mi) == 5) g->start = utcParts(y, mo, d, h, mi);
      break;
    }
  }
  return true;
}

bool matchupName(const char *at) {
  const char *q = at + 13;
  char tmp[24];
  int i = 0;
  while (q[i] && q[i] != '"' && i < 23) {
    tmp[i] = q[i];
    i++;
  }
  tmp[i] = 0;
  return strstr(tmp, " @ ") != nullptr || strstr(tmp, " VS ") != nullptr;
}

const char *nextMatchup(const char *at, const char *limit) {
  const char *p = at + 13;
  while (p < limit) {
    const char *n = strstr(p, "\"shortName\":\"");
    if (!n || n >= limit) return limit;
    if (matchupName(n)) return n;
    p = n + 13;
  }
  return limit;
}

bool blockHasStatus(const char *at, const char *stop) {
  const char *c = strstr(at, "\"displayClock\":\"");
  if (c && c < stop) return true;
  const char *d = strstr(at, "\"shortDetail\":\"");
  return d && d < stop;
}

char *boardBuf(int n) {
  return (char *)heap_caps_malloc((size_t)n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
}

int eatGames(char *win, int *fill, Kick *staging, int n, bool force) {
  while (n < 16) {
    char *at = strstr(win, "\"shortName\":\"");
    if (!at) break;
    int pos = (int)(at - win);
    if (!matchupName(at)) {
      int drop = pos + 13;
      if (drop <= 0 || drop > *fill) break;
      memmove(win, win + drop, *fill - drop);
      *fill -= drop;
      win[*fill] = 0;
      continue;
    }
    char *limit = win + *fill;
    char *stop = (char *)nextMatchup(at, limit);
    bool full = stop < limit;
    bool status = blockHasStatus(at, stop);
    if (!full && !status && !force) break;
    int block = (int)(stop - at);
    if (block > 11000) block = 11000;
    if (block < 14) break;
    static char *blockBuf = nullptr;
    if (!blockBuf) blockBuf = boardBuf(11001);
    if (!blockBuf) return n;
    memcpy(blockBuf, at, (size_t)block);
    blockBuf[block] = 0;
    if (takeGame(blockBuf, win, at, &staging[n])) n++;
    int drop = full ? (int)(stop - win) : pos + 13;
    if (full && drop > 120) drop -= 120;
    if (drop <= 0 || drop > *fill) break;
    memmove(win, win + drop, *fill - drop);
    *fill -= drop;
    win[*fill] = 0;
  }
  return n;
}

int loadBoard(const char *url, Kick *staging, int *weekOut = nullptr) {
  static char *win = nullptr;
  if (!win) win = boardBuf(14001);
  if (!win) return -1;
  int n = 0;
  int fill = 0;
  win[0] = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(15000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, url)) return -1;
  int code = http.GET();
  if (code != 200) {
    http.end();
    cli.stop();
    return -1;
  }
  WiFiClient *stream = http.getStreamPtr();
  if (weekOut) *weekOut = 0;
  uint32_t t0 = millis();
  while (millis() - t0 < 15000) {
    if (weekOut && *weekOut == 0) {
      const char *w = strstr(win, "\"week\":");
      if (w && w < win + fill && w < win + 20000) {
        const char *num = strstr(w, "\"number\":");
        if (num && num < w + 40) *weekOut = atoi(num + 9);
      }
    }
    if (fill > 12000) {
      n = eatGames(win, &fill, staging, n, false);
      if (fill > 12500) {
        char *at = strstr(win, "\"shortName\":\"");
        if (at && at > win) {
          int pos = (int)(at - win);
          int keep = pos > 120 ? 120 : pos;
          memmove(win, at - keep, fill - (pos - keep));
          fill -= pos - keep;
        } else if (!at) {
          memmove(win, win + fill - 800, 800);
          fill = 800;
        }
        win[fill] = 0;
      }
    }
    int space = 14000 - fill;
    if (space < 80) break;
    int avail = stream->available();
    if (avail <= 0) {
      if (!http.connected()) break;
      delay(4);
      continue;
    }
    if (avail > space) avail = space;
    int r = stream->read((uint8_t *)win + fill, avail);
    if (r <= 0) break;
    fill += r;
    win[fill] = 0;
    delay(1);
  }
  http.end();
  cli.stop();
  n = eatGames(win, &fill, staging, n, true);
  return n;
}

int pullGames() {
  static Kick *staging = nullptr;
  if (!staging) staging = (Kick *)boardBuf((int)(sizeof(Kick) * 16));
  if (!staging) return 0;
  int n = loadBoard("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard", staging);
  if (n < 0) return 0;
  publishGames(staging, n);
  return n;
}

int fillWeek(const char *url, Kick *dst, int cap, int *weekOut) {
  if (cap < 1) return -1;
  return loadBoard(url, dst, weekOut);
}

void keepSoon(Kick *got, int *ng, Kick *day, int n, time_t now, time_t end) {
  for (int i = 0; i < n && *ng < 24; i++) {
    if (strcmp(day[i].state, "pre") != 0) continue;
    if (day[i].start <= now || day[i].start > end) continue;
    bool dup = false;
    for (int j = 0; j < *ng; j++) {
      if (strcmp(got[j].name, day[i].name) == 0) dup = true;
    }
    if (!dup) got[(*ng)++] = day[i];
  }
}

int pullSoon() {
  static Kick *day = nullptr;
  static Kick *got = nullptr;
  if (!day) day = (Kick *)boardBuf((int)(sizeof(Kick) * 16));
  if (!got) got = (Kick *)boardBuf((int)(sizeof(Kick) * 24));
  if (!day || !got) return 0;
  time_t now = time(nullptr);
  if (now < 100000) return 0;
  time_t end = now + 7 * 86400;
  int week = 0;
  int ng = 0;
  int hits = 0;
  int n = fillWeek("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard", day, 16, &week);
  if (n >= 0) {
    hits++;
    keepSoon(got, &ng, day, n, now, end);
  }
  if (week >= 1) {
    char url[180];
    snprintf(url, sizeof(url),
             "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?seasontype=2&week=%d",
             week + 1);
    n = fillWeek(url, day, 16, nullptr);
    if (n >= 0) {
      hits++;
      keepSoon(got, &ng, day, n, now, end);
    }
  }
  if (hits == 0) return nSoon;
  for (int a = 1; a < ng; a++) {
    Kick key = got[a];
    int b = a;
    while (b > 0 && got[b - 1].start > key.start) {
      got[b] = got[b - 1];
      b--;
    }
    got[b] = key;
  }
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  nSoon = ng;
  if (ng > 0) memcpy(soon, got, sizeof(Kick) * ng);
  if (gameLock) xSemaphoreGive(gameLock);
  return ng;
}

const char *skyWord(int code) {
  if (code == 0) return "clear";
  if (code <= 3) return "cloud";
  if (code <= 48) return "fog";
  if (code <= 67) return "rain";
  if (code <= 77) return "snow";
  if (code <= 82) return "showers";
  if (code <= 86) return "snow";
  if (code >= 95) return "storm";
  return "weather";
}

bool pullSky() {
  int want = cityIx;
  char url[280];
  snprintf(url, sizeof(url),
           "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
           "&current=temperature_2m,weather_code,wind_speed_10m&temperature_unit=%s"
           "&wind_speed_unit=mph&timezone=auto",
           CITIES[want].lat, CITIES[want].lon, useC ? "celsius" : "fahrenheit");
  static char *body = nullptr;
  if (!body) body = boardBuf(1400);
  if (!body) return false;
  body[0] = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(12000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  if (!http.begin(cli, url)) return false;
  int code = http.GET();
  if (code == 200) {
    WiFiClient *stream = http.getStreamPtr();
    int got = 0;
    uint32_t t0 = millis();
    while (got < 1400 - 1 && millis() - t0 < 12000) {
      int a = stream->available();
      if (a <= 0) {
        if (!http.connected()) break;
        delay(2);
        continue;
      }
      if (a > 1400 - 1 - got) a = 1400 - 1 - got;
      int r = stream->read((uint8_t *)body + got, a);
      if (r <= 0) break;
      got += r;
    }
    body[got] = 0;
  }
  http.end();
  cli.stop();
  if (cityIx != want) {
    cityOffOk = false;
    return false;
  }
  const char *op = strstr(body, "\"utc_offset_seconds\":");
  if (op) {
    cityOff = atoi(op + 21);
    cityOffOk = true;
  }
  const char *cur = strstr(body, "\"current\":{");
  if (!cur || !strstr(cur, "temperature_2m")) {
    skyOk = false;
    return false;
  }
  const char *tp = strstr(cur, "\"temperature_2m\":");
  const char *wp = strstr(cur, "\"wind_speed_10m\":");
  const char *cp = strstr(cur, "\"weather_code\":");
  if (tp) skyTemp = (float)atof(tp + 17);
  if (wp) skyWind = (float)atof(wp + 17);
  if (cp) skyCode = atoi(cp + 15);
  skyOk = tp != nullptr;
  return skyOk;
}

void loadSeason() {
  EEPROM.begin(512);
  EEPROM.get(0, season);
  if (season.magic != 0x4B31 || season.n > 32) memset(&season, 0, sizeof(season));
}

void saveSeason() {
  season.magic = 0x4B31;
  EEPROM.put(0, season);
  EEPROM.commit();
}

bool teamMark(const char *p, char *ab) {
  if (strncmp(p, "\"abbreviation\":\"", 16) != 0) return false;
  const char *s = p + 16;
  int n = 0;
  while (s[n] && s[n] != '"' && n < 4) n++;
  if (n < 2 || n > 3 || s[n] != '"') return false;
  if (strncmp(s + n, "\",\"displayName\":\"", 17) != 0) return false;
  memcpy(ab, s, (size_t)n);
  ab[n] = 0;
  return true;
}

void pushSeason(SeasonRow *got, int *ng, const char *ab, int w, int l, int t) {
  if (!ab[0] || w < 0 || l < 0 || *ng >= 32) return;
  for (int i = 0; i < *ng; i++) {
    if (strcmp(got[i].ab, ab) == 0) return;
  }
  if (t < 0) t = 0;
  if (w > 255) w = 255;
  if (l > 255) l = 255;
  if (t > 255) t = 255;
  strlcpy(got[*ng].ab, ab, 4);
  got[*ng].w = (uint8_t)w;
  got[*ng].l = (uint8_t)l;
  got[*ng].t = (uint8_t)t;
  (*ng)++;
}

bool pullStandings() {
  static char *buf = nullptr;
  if (!buf) buf = boardBuf(2200);
  if (!buf) return false;
  SeasonRow got[32];
  int ng = 0;
  int fill = 0;
  int scan = 0;
  char ab[4];
  ab[0] = 0;
  int w = -1, l = -1, t = -1, pend = 0;
  uint16_t year = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(20000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, "https://site.api.espn.com/apis/v2/sports/football/nfl/standings")) return false;
  int code = http.GET();
  if (code != 200) {
    http.end();
    cli.stop();
    return false;
  }
  WiFiClient *stream = http.getStreamPtr();
  uint32_t t0 = millis();
  bool ended = false;
  while (millis() - t0 < 20000) {
    int space = 2200 - 1 - fill;
    int avail = stream->available();
    if (avail > 0 && space > 0) {
      if (avail > space) avail = space;
      int r = stream->read((uint8_t *)buf + fill, avail);
      if (r <= 0) ended = true;
      else {
        fill += r;
        buf[fill] = 0;
      }
    } else if (!http.connected()) ended = true;
    else delay(4);
    int limit = ended ? fill : fill - 48;
    while (scan < limit) {
      const char *p = buf + scan;
      if (!year && strncmp(p, "\"season\":", 9) == 0 && isdigit((unsigned char)p[9])) {
        int yv = atoi(p + 9);
        if (yv > 2000 && yv < 2100) year = (uint16_t)yv;
      }
      if (!year && strncmp(p, "\"year\":", 7) == 0 && isdigit((unsigned char)p[7])) {
        int yv = atoi(p + 7);
        if (yv > 2000 && yv < 2100) year = (uint16_t)yv;
      }
      char nab[4];
      if (teamMark(p, nab)) {
        pushSeason(got, &ng, ab, w, l, t);
        strlcpy(ab, nab, 4);
        w = l = t = -1;
        pend = 0;
        scan += 16;
        continue;
      }
      if (strncmp(p, "\"name\":\"wins\"", 13) == 0) {
        pend = 1;
        scan += 13;
        continue;
      }
      if (strncmp(p, "\"name\":\"losses\"", 15) == 0) {
        pend = 2;
        scan += 15;
        continue;
      }
      if (strncmp(p, "\"name\":\"ties\"", 13) == 0) {
        pend = 3;
        scan += 13;
        continue;
      }
      if (pend && strncmp(p, "\"value\":", 8) == 0) {
        int v = atoi(p + 8);
        if (pend == 1) w = v;
        else if (pend == 2) l = v;
        else t = v;
        pend = 0;
        scan += 8;
        continue;
      }
      scan++;
    }
    if (fill > 1800) {
      int keep = 200;
      int base = fill - keep;
      if (base < 0) base = 0;
      int scanned = scan - base;
      if (scanned < 0) scanned = 0;
      memmove(buf, buf + base, (size_t)(fill - base));
      fill -= base;
      buf[fill] = 0;
      scan = scanned;
    }
    if (ended) break;
  }
  pushSeason(got, &ng, ab, w, l, t);
  http.end();
  cli.stop();
  if (ng < 30) return false;
  if (year && season.year && year != season.year) memset(&season, 0, sizeof(season));
  if (year) season.year = year;
  season.n = (uint8_t)ng;
  for (int i = 0; i < ng; i++) season.row[i] = got[i];
  saveSeason();
  return true;
}

void netTask(void *) {
  for (;;) {
    if (job == 1) {
      pullGames();
      lastGames = millis();
      job = 0;
      busy = false;
      dirty = true;
    } else if (job == 2) {
      pullSky();
      lastSky = millis();
      job = 0;
      busy = false;
      dirty = true;
    } else if (job == 3) {
      runOtaJob();
      job = 0;
    } else if (job == 4) {
      pullStandings();
      lastSeason = millis();
      job = 0;
      busy = false;
      dirty = true;
    } else if (job == 5) {
      pullSoon();
      if (time(nullptr) > 100000) lastSoon = millis();
      shiftFix = true;
      job = 0;
      busy = false;
      dirty = true;
    }
    vTaskDelay(pdMS_TO_TICKS(40));
  }
}

int boardCols() { return SW >= 700 ? 2 : 1; }
int cardH() { return SH >= 400 ? 112 : 36; }

int boardRows() {
  int n = (SH >= 400 ? (SH - 48 - 60) : (246 - 24)) / (cardH() + (SH >= 400 ? 6 : 4));
  if (n < 1) n = 1;
  return n;
}

bool scrollOn(int n) { return n > boardRows() * boardCols(); }

int clockX(bool scrolling) { return scrolling ? (SH >= 400 ? 148 : 100) : (SH >= 400 ? SW - 156 : SW - 110); }

void clockText(char *out, int cap) {
  time_t now = time(nullptr);
  if (now < 100000) {
    strlcpy(out, "--:--", cap);
    return;
  }
  struct tm t;
  localtime_r(&now, &t);
  int h = t.tm_hour % 12;
  if (h == 0) h = 12;
  snprintf(out, cap, "%d:%02d %s", h, t.tm_min, t.tm_hour < 12 ? "AM" : "PM");
}

void cityClockText(char *out, int cap) {
  if (!cityOffOk) {
    strlcpy(out, "--:--", cap);
    return;
  }
  time_t now = time(nullptr);
  if (now < 100000) {
    strlcpy(out, "--:--", cap);
    return;
  }
  now += (time_t)cityOff;
  struct tm t;
  gmtime_r(&now, &t);
  int h = t.tm_hour % 12;
  if (h == 0) h = 12;
  snprintf(out, cap, "%d:%02d %s", h, t.tm_min, t.tm_hour < 12 ? "AM" : "PM");
}

void cityDateText(char *out, int cap) {
  out[0] = 0;
  if (!cityOffOk) return;
  time_t now = time(nullptr);
  if (now < 100000) return;
  now += (time_t)cityOff;
  struct tm t;
  gmtime_r(&now, &t);
  static const char *mon[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
  snprintf(out, cap, "%s %d", mon[t.tm_mon], t.tm_mday);
}

void paintChipRow() {
  const char *names[] = {"BOARD", "NEXT", "TEMP", "TEAM", "WIFI", "UPDATE"};
  int n = 6;
  int gap = 4;
  int w = (SW - 8 - gap * (n - 1)) / n;
  int y = SH >= 400 ? SH - 52 : SH - 24;
  int bh = SH >= 400 ? 28 : 18;
  for (int i = 0; i < n; i++) {
    int x = 4 + i * (w + gap);
    bool on = page == i;
    gfx->fillRoundRect(x, y, w, bh, 4, on ? COL_GOLD : COL_CARD);
    gfx->setTextSize(1);
    gfx->setTextColor(on ? COL_BG : COL_WHITE);
    int tw = (int)strlen(names[i]) * 6;
    gfx->setCursor(x + (w - tw) / 2, y + (bh - 8) / 2);
    gfx->print(names[i]);
  }
}

bool chipHit(int x, int y, int i) {
  int n = 6;
  int gap = 4;
  int w = (SW - 8 - gap * (n - 1)) / n;
  int bx = 4 + i * (w + gap);
  int by = SH >= 400 ? SH - 52 : SH - 24;
  int bh = SH >= 400 ? 28 : 18;
  return hit(x, y, bx, by, bx + w, by + bh);
}

void seasonAt(int *x, int *y, int *w, int *h, bool scrolling) {
  if (SH >= 400) {
    *y = 16;
    *h = 24;
    *w = 96;
    int edge = scrolling ? (SW - 156) : clockX(false);
    *x = edge - 8 - *w;
  } else {
    *y = 2;
    *h = 16;
    *w = 84;
    int edge = scrolling ? (SW - 108) : clockX(false);
    *x = edge - 4 - *w;
  }
  if (*x < 4) *x = 4;
}

void titleRow(const char *title, bool scrolling, bool seasonBtn) {
  bool tall = SH >= 400;
  int sx = 0, sy = 0, bw = 0, bh = 0;
  int clkAt = clockX(scrolling);
  if (seasonBtn) {
    seasonAt(&sx, &sy, &bw, &bh, scrolling);
    int clkW = (tall ? 3 : 2) * 6 * 8;
    if (clkAt < sx + bw && clkAt + clkW > sx - 4) {
      clkAt = sx - 6 - clkW;
      if (clkAt < (tall ? 108 : 70)) clkAt = tall ? 108 : 70;
    }
  }
  clkDrawX = clkAt;
  gfx->setTextSize(tall ? 2 : 1);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, tall ? 22 : 4);
  gfx->print(title);
  char clk[16];
  if (page == PG_BOARD || page == PG_NEXT || page == PG_WEEK) cityClockText(clk, sizeof(clk));
  else clockText(clk, sizeof(clk));
  gfx->setTextSize(tall ? 3 : 2);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(clkAt, tall ? 16 : 2);
  if (page != PG_SKY && page != PG_TODAY && page != PG_TEAM) gfx->print(clk);
  if (seasonBtn) {
    bool on = page == PG_SEASON;
    gfx->fillRoundRect(sx, sy, bw, bh, tall ? 4 : 3, on ? COL_GOLD : COL_CARD);
    const char *lab = (page == PG_SEASON) ? "BACK" : "LEADER BOARD";
    int tw = (int)strlen(lab) * 6;
    gfx->setTextSize(1);
    gfx->setTextColor(on ? COL_BG : COL_WHITE);
    gfx->setCursor(sx + (bw - tw) / 2, sy + (tall ? 8 : 4));
    gfx->print(lab);
  }
  if (scrolling) {
    if (tall) {
      gfx->fillRoundRect(SW - 156, 16, 70, 24, 4, COL_CARD);
      gfx->fillRoundRect(SW - 78, 16, 70, 24, 4, COL_CARD);
      gfx->setTextSize(1);
      gfx->setTextColor(COL_WHITE);
      gfx->setCursor(SW - 136, 22);
      gfx->print("UP");
      gfx->setCursor(SW - 58, 22);
      gfx->print("DN");
    } else {
      gfx->fillRoundRect(SW - 108, 2, 48, 16, 3, COL_CARD);
      gfx->fillRoundRect(SW - 54, 2, 48, 16, 3, COL_CARD);
      gfx->setTextSize(1);
      gfx->setTextColor(COL_WHITE);
      gfx->setCursor(SW - 94, 6);
      gfx->print("UP");
      gfx->setCursor(SW - 40, 6);
      gfx->print("DN");
    }
  }
}

void titleRow(const char *title, bool scrolling) {
  titleRow(title, scrolling, false);
}

bool listedAs(const char *name, const char *ab) {
  if (!ab || !ab[0]) return false;
  int n = (int)strlen(ab);
  const char *p = strstr(name, ab);
  if (!p) return false;
  bool left = (p == name) || p[-1] == ' ';
  bool right = p[n] == 0 || p[n] == ' ';
  return left && right;
}

bool hasTeam(const char *name, const char *ab) {
  if (!ab[0]) return false;
  if (listedAs(name, ab)) return true;
  if (strcmp(ab, "WAS") == 0) return listedAs(name, "WSH");
  if (strcmp(ab, "WSH") == 0) return listedAs(name, "WAS");
  return false;
}

void centreAt(const char *s, int y, int size, uint16_t col) {
  gfx->setTextSize(size);
  gfx->setTextColor(col);
  int n = (int)strlen(s);
  int w = n * 6 * size;
  int x = (SW - w) / 2;
  if (x < 2) x = 2;
  gfx->setCursor(x, y);
  gfx->print(s);
}

int textFit(const char *s, int maxW, int maxH, int cap) {
  int n = (int)strlen(s);
  if (n < 1) n = 1;
  int a = maxW / (n * 6);
  int b = maxH / 8;
  int z = a < b ? a : b;
  if (z < 2) z = 2;
  if (z > cap) z = cap;
  return z;
}

int teamIx(const char *ab) {
  if (!ab) return -1;
  if (strcmp(ab, "WSH") == 0) ab = "WAS";
  for (int i = 0; i < N_TEAMS; i++)
    if (strcmp(TEAMS[i], ab) == 0) return i;
  return -1;
}

void drawMark(const char *ab, int x, int y, int px) {
  int ix = teamIx(ab);
  if (ix < 0 || px < 8 || px > 32) return;
  static uint16_t buf[32 * 32];
  for (int row = 0; row < px; row++) {
    int sy = row * MARK_PX / px;
    for (int col = 0; col < px; col++) {
      int sx = col * MARK_PX / px;
      buf[row * px + col] = pgm_read_word(&MARKS[ix][sy * MARK_PX + sx]);
    }
  }
  gfx->draw16bitRGBBitmap(x, y, buf, px, px);
}

void drawSide(int x, int y, const char *ab, const char *pts, int px) {
  if (!ab || !ab[0]) return;
  drawMark(ab, x, y, px);
  int ts = px >= 28 ? 2 : 1;
  gfx->setTextSize(ts);
  gfx->setTextColor(COL_WHITE);
  int ty = y + (px - 8 * ts) / 2;
  if (ty < y) ty = y;
  gfx->setCursor(x + px + 4, ty);
  gfx->print(ab);
  if (pts && pts[0]) {
    gfx->setTextColor(COL_GOLD);
    gfx->print(" ");
    gfx->print(pts);
  }
}

void backAt(int *x, int *y, int *w, int *h) {
  int sx, sy, sw, sh;
  seasonAt(&sx, &sy, &sw, &sh, false);
  if (SH >= 400) {
    *w = 70;
    *h = 24;
  } else {
    *w = 48;
    *h = 16;
  }
  *y = sy;
  *x = sx - (SH >= 400 ? 8 : 4) - *w;
  if (*x < 4) *x = 4;
}

void drawBack() {
  int x, y, w, h;
  backAt(&x, &y, &w, &h);
  gfx->fillRoundRect(x, y, w, h, SH >= 400 ? 4 : 3, COL_CARD);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(x + (w - 24) / 2, y + (h - 8) / 2);
  gfx->print("BACK");
}

void clearAt(int *x, int *y, int *w, int *h) {
  int bx, by, bw, bh;
  backAt(&bx, &by, &bw, &bh);
  *h = bh;
  *y = by;
  *w = SH >= 400 ? 78 : 54;
  *x = bx - (SH >= 400 ? 8 : 4) - *w;
  if (*x < 4) *x = 4;
}

void drawClear() {
  int x, y, w, h;
  clearAt(&x, &y, &w, &h);
  gfx->fillRoundRect(x, y, w, h, SH >= 400 ? 4 : 3, COL_CARD);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_WHITE);
  int tw = 5 * 6;
  gfx->setCursor(x + (w - tw) / 2, y + (h - 8) / 2);
  gfx->print("CLEAR");
}

void gameLine(const Kick *g, char *out, int cap) {
  if (g->detail[0]) {
    strlcpy(out, g->detail, cap);
    return;
  }
  if (g->start < 100000) {
    out[0] = 0;
    return;
  }
  time_t when = g->start;
  struct tm t;
  if (cityOffOk) {
    when += (time_t)cityOff;
    gmtime_r(&when, &t);
  } else {
    localtime_r(&when, &t);
  }
  int h = t.tm_hour % 12;
  if (h == 0) h = 12;
  snprintf(out, cap, "%d/%d  %d:%02d %s", t.tm_mon + 1, t.tm_mday, h, t.tm_min,
           t.tm_hour < 12 ? "AM" : "PM");
}

void drawFocusGame(const Kick *g) {
  int x = 8;
  int y = SH >= 400 ? 52 : 22;
  int bot = SH >= 400 ? SH - 58 : SH - 28;
  int w = SW - 16;
  int h = bot - y;
  if (h < 40) h = 40;
  gfx->fillRoundRect(x, y, w, h, 8, COL_CARD);
  gfx->drawRoundRect(x, y, w, h, 8, COL_LINE);
  int ns = SH >= 400 ? 4 : 2;
  centreAt(g->name, y + 10, ns, COL_WHITE);
  int y2 = y + 10 + ns * 8 + 6;
  char info[36];
  gameLine(g, info, sizeof(info));
  if (info[0]) {
    int ds = SH >= 400 ? 3 : 2;
    uint16_t col = strcmp(g->state, "in") == 0 ? COL_GREEN : COL_DIM;
    centreAt(info, y2, ds, col);
    y2 += ds * 8 + 8;
  }
  int px = 32;
  int roomH = (y + h) - y2 - 28;
  if (roomH < 64) roomH = 64;
  int roomW = (w / 2) - px - 28;
  const char *as = g->aPts[0] ? g->aPts : "-";
  const char *hs = g->hPts[0] ? g->hPts : "-";
  int digits = (int)strlen(as);
  if ((int)strlen(hs) > digits) digits = (int)strlen(hs);
  if (digits < 1) digits = 1;
  int sz = roomH / 8;
  int szW = roomW / (digits * 6);
  if (szW < sz) sz = szW;
  if (sz < 4) sz = 4;
  if (sz > 28) sz = 28;
  int mid = SW / 2;
  int ty = y2 + (roomH - sz * 8) / 2;
  if (ty < y2) ty = y2;
  int my = y2 + (roomH - px) / 2;
  if (my < y2) my = y2;
  drawMark(g->away, x + 12, my, px);
  drawMark(g->home, mid + 8, my, px);
  gfx->setTextSize(sz);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(x + 16 + px + 8, ty);
  gfx->print(as);
  gfx->setCursor(mid + 12 + px, ty);
  gfx->print(hs);
  int ly = y + h - (SH >= 400 ? 28 : 16);
  gfx->setTextSize(SH >= 400 ? 2 : 1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(x + 12, ly);
  gfx->print(g->away);
  gfx->setCursor(mid + 8, ly);
  gfx->print(g->home);
}

int copyToday(Kick *dst);

int focusGame(Kick *view, int n) {
  if (!focusName[0]) return n;
  for (int i = 0; i < n; i++) {
    if (strcmp(view[i].name, focusName) == 0) {
      if (i != 0) view[0] = view[i];
      return 1;
    }
  }
  Kick done[16];
  int nd = copyToday(done);
  for (int i = 0; i < nd; i++) {
    if (strcmp(done[i].name, focusName) == 0) {
      view[0] = done[i];
      return 1;
    }
  }
  focusName[0] = 0;
  return n;
}

void drawBoard() {
  Kick view[16];
  int n = copyGames(view);
  n = focusGame(view, n);
  int cols = focusName[0] ? 1 : boardCols();
  int rows = boardRows();
  int vis = rows * cols;
  if (gTop < 0) gTop = 0;
  if (gTop > 0 && gTop >= n) gTop = 0;
  gfx->fillScreen(COL_BG);
  titleRow("KICKOFF", scrollOn(n), true);
  {
    int ix = pickNext(view, n);
    char left[20];
    left[0] = 0;
    if (ix >= 0 && strcmp(view[ix].state, "in") == 0) strlcpy(left, "ON NOW", sizeof(left));
    else if (ix >= 0 && view[ix].start > 100000) fmtRemain(view[ix].start, left, sizeof(left));
    char dat[12];
    cityDateText(dat, sizeof(dat));
    int x = SH >= 400 ? 108 : 60;
    int y = SH >= 400 ? 26 : 4;
    int stop = clkDrawX - 6;
    if (left[0]) {
      int maxc = (stop - x) / 6;
      if (maxc > 0) {
        if ((int)strlen(left) > maxc) left[maxc] = 0;
        gfx->setTextSize(1);
        gfx->setTextColor(COL_GOLD);
        gfx->setCursor(x, y);
        gfx->print(left);
        x += (int)strlen(left) * 6 + 8;
      }
    }
    if (dat[0]) {
      int maxc = (stop - x) / 6;
      if (maxc >= (int)strlen(dat)) {
        gfx->setTextSize(1);
        gfx->setTextColor(COL_DIM);
        gfx->setCursor(x, y);
        gfx->print(dat);
      }
    }
  }
  if (!wifiOk) {
    gfx->setTextSize(1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, 28);
    gfx->print("no link yet");
  } else if (n <= 0) {
    gfx->setTextSize(1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, 28);
    gfx->print(busy ? "reading the board" : "no games listed");
  }
  if (focusName[0] && n == 1) {
    drawFocusGame(&view[0]);
    drawBack();
    drawClear();
    paintChipRow();
    return;
  }
  int gap = SH >= 400 ? 6 : 4;
  int cw = (SW - 12 - gap * (cols - 1)) / cols;
  int ch = cardH();
  int shown = 0;
  int y0 = SH >= 400 ? 48 : 24;
  for (int i = gTop; i < n && shown < vis; i++, shown++) {
    int col = shown % cols;
    int row = shown / cols;
    int x = 6 + col * (cw + gap);
    int y = y0 + row * (ch + gap);
    bool mine = hasTeam(view[i].name, fav);
    gfx->fillRoundRect(x, y, cw, ch, 6, COL_CARD);
    gfx->drawRoundRect(x, y, cw, ch, 6, mine ? COL_GOLD : COL_LINE);
    gfx->setTextSize(SH >= 400 ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(x + 6, y + 2);
    gfx->print(view[i].name);
    gfx->setTextSize(1);
    if (strcmp(view[i].state, "in") == 0) {
      const char *lab = view[i].detail[0] ? view[i].detail : "LIVE";
      gfx->setTextColor(COL_GREEN);
      int tw = (int)strlen(lab) * 6;
      int tx = x + cw - 6 - tw;
      if (tx < x + 6) tx = x + 6;
      gfx->setCursor(tx, y + 2);
      gfx->print(lab);
    } else if (strcmp(view[i].state, "post") == 0) {
      gfx->setTextColor(COL_DIM);
      gfx->setCursor(x + cw - 40, y + 2);
      gfx->print("FINAL");
    }
    int px = ch >= 100 ? 32 : (ch >= 50 ? 20 : 12);
    int sy = y + (ch >= 100 ? 34 : 12);
    drawSide(x + 8, sy, view[i].away, view[i].aPts, px);
    drawSide(x + cw / 2, sy, view[i].home, view[i].hPts, px);
    gfx->setTextSize(1);
    gfx->setTextColor(strcmp(view[i].state, "in") == 0 ? COL_GREEN : COL_DIM);
    gfx->setCursor(x + 6, y + ch - 10);
    char info[36];
    gameLine(&view[i], info, sizeof(info));
    gfx->print(info);
  }
  if (focusName[0]) {
    drawBack();
    drawClear();
  }
  paintChipRow();
}

void fmtRemain(time_t when, char *out, int cap) {
  time_t now = time(nullptr);
  long s = (long)(when - now);
  if (s < 0) s = 0;
  int d = (int)(s / 86400);
  int h = (int)((s % 86400) / 3600);
  int m = (int)((s % 3600) / 60);
  if (d > 0) snprintf(out, cap, "%dd %dh %dm", d, h, m);
  else snprintf(out, cap, "%dh %dm", h, m);
}

void drawNavRemain(Kick *view, int n) {
  time_t now = time(nullptr);
  time_t soon = 0;
  int ix = -1;
  for (int i = 0; i < n; i++) {
    if (strcmp(view[i].state, "in") == 0) continue;
    if (gameOver(&view[i])) continue;
    if (view[i].start <= now + 20) continue;
    if (ix < 0 || view[i].start < soon) {
      ix = i;
      soon = view[i].start;
    }
  }
  if (ix < 0) return;
  char rem[20];
  fmtRemain(view[ix].start, rem, sizeof(rem));
  int bx, by, bw, bh;
  seasonAt(&bx, &by, &bw, &bh, false);
  int sz = SH >= 400 ? 2 : 1;
  int tw = (int)strlen(rem) * 6 * sz;
  int x = bx - 6 - tw;
  int minx = SH >= 400 ? 64 : 36;
  if (x < minx) x = minx;
  gfx->setTextSize(sz);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(x, SH >= 400 ? 18 : 4);
  gfx->print(rem);
}

void drawDayBtn(bool back, bool scrolling) {
  int x, y, w, h;
  seasonAt(&x, &y, &w, &h, scrolling);
  gfx->fillRoundRect(x, y, w, h, SH >= 400 ? 4 : 3, COL_CARD);
  const char *lab = back ? "BACK" : "TODAY";
  int tw = (int)strlen(lab) * 6;
  gfx->setTextSize(1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(x + (w - tw) / 2, y + (h - 8) / 2);
  gfx->print(lab);
}

int copyToday(Kick *dst) {
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  rollToday();
  int n = nToday;
  if (n > 16) n = 16;
  if (n > 0) memcpy(dst, today, sizeof(Kick) * n);
  if (gameLock) xSemaphoreGive(gameLock);
  return n;
}

bool todayNeedsScroll(int n, int *visOut) {
  int top = SH >= 400 ? 52 : 22;
  int bot = SH >= 400 ? SH - 58 : SH - 28;
  int rh = SH >= 400 ? 22 : 16;
  int cols = (SW < 700 && n > 6) ? 2 : 1;
  int rows = n <= 0 ? 0 : (n + cols - 1) / cols;
  int vis = (bot - top) / rh;
  if (vis < 1) vis = 1;
  if (visOut) *visOut = vis;
  return rows > vis;
}

void drawToday() {
  Kick view[16];
  int n = copyToday(view);
  int vis = 1;
  bool scroll = todayNeedsScroll(n, &vis);
  int cols = (SW < 700 && n > 6) ? 2 : 1;
  int rows = n <= 0 ? 0 : (n + cols - 1) / cols;
  if (todayTop > rows - vis) todayTop = rows - vis;
  if (todayTop < 0) todayTop = 0;
  gfx->fillScreen(COL_BG);
  titleRow("TODAY", scroll);
  drawDayBtn(true, scroll);
  int top = SH >= 400 ? 52 : 22;
  int bot = SH >= 400 ? SH - 58 : SH - 28;
  if (n <= 0) {
    gfx->setTextSize(SH >= 400 ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, top + 8);
    gfx->print("no finals yet");
    paintChipRow();
    return;
  }
  int rh = SH >= 400 ? 22 : 16;
  int ts = (rh >= 20 && SW >= 700) ? 2 : 1;
  int cw = (SW - 16) / cols;
  for (int i = 0; i < n; i++) {
    int c = i / rows;
    int r = i % rows;
    if (r < todayTop || r >= todayTop + vis) continue;
    int x = 8 + c * cw;
    int y = top + (r - todayTop) * rh;
    char line[80];
    snprintf(line, sizeof(line), "%s  %s-%s  %s", view[i].name,
             view[i].aPts[0] ? view[i].aPts : "-",
             view[i].hPts[0] ? view[i].hPts : "-", view[i].detail);
    gfx->setTextSize(ts);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(x, y);
    gfx->print(line);
  }
  paintChipRow();
}

int pickNext(Kick *view, int n) {
  time_t now = time(nullptr);
  int liveFav = -1, liveAny = -1, futFav = -1, futAny = -1;
  time_t soon = 0;
  for (int i = 0; i < n; i++) {
    if (gameOver(&view[i])) continue;
    if (strcmp(view[i].state, "in") == 0) {
      if (liveAny < 0) liveAny = i;
      if (hasTeam(view[i].name, fav)) liveFav = i;
    }
    if (view[i].start > now + 20) {
      if (futAny < 0 || view[i].start < soon) {
        futAny = i;
        soon = view[i].start;
      }
      if (hasTeam(view[i].name, fav)) {
        if (futFav < 0 || view[i].start < view[futFav].start) futFav = i;
      }
    }
  }
  if (liveFav >= 0) return liveFav;
  if (liveAny >= 0) return liveAny;
  if (futFav >= 0) return futFav;
  return futAny;
}

void drawRemainBig(time_t when, int y0, int y1) {
  time_t now = time(nullptr);
  long s = (long)(when - now);
  if (s < 0) s = 0;
  int d = (int)(s / 86400);
  int h = (int)((s % 86400) / 3600);
  int m = (int)((s % 3600) / 60);
  char da[8], ha[8], ma[8];
  const char *num[3];
  const char *lab[3];
  int n;
  if (d > 0) {
    snprintf(da, sizeof(da), "%d", d);
    snprintf(ha, sizeof(ha), "%d", h);
    snprintf(ma, sizeof(ma), "%d", m);
    num[0] = da;
    lab[0] = "DAYS";
    num[1] = ha;
    lab[1] = "HOURS";
    num[2] = ma;
    lab[2] = "MIN";
    n = 3;
  } else {
    snprintf(ha, sizeof(ha), "%d", h);
    snprintf(ma, sizeof(ma), "%d", m);
    num[0] = ha;
    lab[0] = "HOURS";
    num[1] = ma;
    lab[1] = "MIN";
    n = 2;
  }
  int gap = 8;
  int cw = (SW - 16 - gap * (n - 1)) / n;
  int labPx = SH >= 400 ? 20 : 12;
  int numH = (y1 - y0) - labPx - 4;
  if (numH < 24) numH = 24;
  int sz = 16;
  for (int i = 0; i < n; i++) {
    int z = textFit(num[i], cw - 4, numH, SH >= 400 ? 14 : 3);
    if (z < sz) sz = z;
  }
  int labSize = SH >= 400 ? 2 : 1;
  for (int i = 0; i < n; i++) {
    int x = 8 + i * (cw + gap);
    int nw = (int)strlen(num[i]) * 6 * sz;
    gfx->setTextSize(sz);
    gfx->setTextColor(COL_GOLD);
    gfx->setCursor(x + (cw - nw) / 2, y0);
    gfx->print(num[i]);
    int lw = (int)strlen(lab[i]) * 6 * labSize;
    gfx->setTextSize(labSize);
    gfx->setTextColor(COL_DIM);
    gfx->setCursor(x + (cw - lw) / 2, y0 + sz * 8 + 2);
    gfx->print(lab[i]);
  }
}

void nextNavBox(int which, int *x, int *y, int *w, int *h) {
  if (SH >= 400) {
    *w = 70;
    *h = 24;
    *y = 16;
    *x = clockX(false) - 8 - *w - (1 - which) * (8 + *w);
  } else {
    *w = 52;
    *h = 16;
    *y = 2;
    *x = clockX(false) - 4 - *w - (1 - which) * (4 + *w);
  }
}

void weekAt(int *x, int *y, int *w, int *h) {
  int bx, by, bw, bh;
  nextNavBox(0, &bx, &by, &bw, &bh);
  *w = bw;
  *h = bh;
  *y = by;
  int gap = SH >= 400 ? 8 : 4;
  *x = bx - gap - *w;
  if (*x < 4) *x = 4;
}

void drawNextNav() {
  const char *labs[2] = {"BACK", "NEXT"};
  for (int i = 0; i < 2; i++) {
    int x, y, w, h;
    nextNavBox(i, &x, &y, &w, &h);
    gfx->fillRoundRect(x, y, w, h, SH >= 400 ? 4 : 3, COL_CARD);
    int tw = (int)strlen(labs[i]) * 6;
    gfx->setTextSize(1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(x + (w - tw) / 2, y + (h - 8) / 2);
    gfx->print(labs[i]);
  }
  int x, y, w, h;
  weekAt(&x, &y, &w, &h);
  gfx->fillRoundRect(x, y, w, h, SH >= 400 ? 4 : 3, COL_CARD);
  const char *lab = "7 DAYS";
  int tw = (int)strlen(lab) * 6;
  gfx->setTextSize(1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(x + (w - tw) / 2, y + (h - 8) / 2);
  gfx->print(lab);
}

void drawNext() {
  Kick view[16];
  int n = copyGames(view);
  int liveIx[8];
  int nLive = 0;
  for (int i = 0; i < n && nLive < 8; i++) {
    if ((strcmp(view[i].state, "in") == 0 || strcmp(view[i].state, "post") == 0 ||
         strncmp(view[i].detail, "Final", 5) == 0) &&
        !gameOver(&view[i]))
      liveIx[nLive++] = i;
  }
  if (nLive > 0) {
    gfx->fillScreen(COL_BG);
    titleRow("NEXT", false);
    int top = SH >= 400 ? 52 : 24;
    int bot = SH >= 400 ? SH - 58 : SH - 28;
    int gap = 4;
    int fit = (bot - top - gap * (nLive - 1)) / nLive;
    int rh = SH >= 400 ? 88 : 44;
    if (fit < rh) rh = fit;
    if (rh < 28) rh = 28;
    for (int k = 0; k < nLive; k++) {
      const Kick *g = &view[liveIx[k]];
      int y = top + k * (rh + gap);
      int x = 8;
      int w = SW - 16;
      gfx->fillRoundRect(x, y, w, rh, 6, COL_CARD);
      int ns = (SH >= 400 && rh >= 70) ? 2 : 1;
      gfx->setTextSize(ns);
      gfx->setTextColor(COL_WHITE);
      gfx->setCursor(x + 8, y + 4);
      gfx->print(g->name);
      if (g->detail[0]) {
        gfx->setTextSize(1);
        gfx->setTextColor(COL_GREEN);
        gfx->setCursor(x + 8, y + 6 + ns * 8);
        gfx->print(g->detail);
      }
      int px = rh >= 90 ? 32 : (rh >= 50 ? 20 : 12);
      int sy = y + rh - px - 4;
      if (sy < y + 4) sy = y + 4;
      drawSide(x + 8, sy, g->away, g->aPts, px);
      drawSide(x + w / 2, sy, g->home, g->hPts, px);
    }
    drawNextNav();
    paintChipRow();
    return;
  }
  int ix = pickNext(view, n);
  gfx->fillScreen(COL_BG);
  titleRow("NEXT", false);
  int y = SH >= 400 ? 40 : 22;
  if (ix >= 0) {
    int ns = SH >= 400 ? 3 : 1;
    int mates[8];
    int nm = 0;
    for (int i = 0; i < n && nm < 8; i++) {
      if (view[i].start > 100000 && view[i].start == view[ix].start) mates[nm++] = i;
    }
    if (nm < 1) {
      mates[0] = ix;
      nm = 1;
    }
    int use = nm > 1 ? (SH >= 400 ? 2 : 1) : ns;
    for (int i = 0; i < nm; i++) {
      char line[40];
      const Kick *g = &view[mates[i]];
      if (strcmp(g->state, "in") == 0 && g->detail[0])
        snprintf(line, sizeof(line), "%s  %s", g->name, g->detail);
      else
        strlcpy(line, g->name, sizeof(line));
      centreAt(line, y, use, strcmp(g->state, "in") == 0 ? COL_GREEN : COL_WHITE);
      y += use * 8 + 2;
    }
  }
  int bot = SH - 40;
  if (ix < 0) {
    centreAt(wifiOk ? "no kickoff listed" : "no link yet", y + 4, 1, COL_WHITE);
  } else if (strcmp(view[ix].state, "in") == 0) {
    int room = bot - y;
    if (room < 32) room = 32;
    int z = textFit("ON NOW", SW - 16, room / 2, SH >= 400 ? 8 : 2);
    centreAt("ON NOW", y, z, COL_GREEN);
    y += z * 8 + 4;
    if (view[ix].detail[0] && y + 16 < bot) {
      int ds = SH >= 400 ? 3 : 2;
      centreAt(view[ix].detail, y, ds, COL_GREEN);
      y += ds * 8 + 4;
    }
    int px = SH >= 400 ? 32 : 14;
    if (y + px < bot) {
      drawSide(SW / 4 - px, y, view[ix].away, view[ix].aPts, px);
      drawSide(SW / 2 + 8, y, view[ix].home, view[ix].hPts, px);
    }
  } else if (view[ix].start > 100000) {
    int lab = SH >= 400 ? 24 : 14;
    drawRemainBig(view[ix].start, y, bot - lab);
  } else {
    centreAt(view[ix].detail, y + 4, 1, COL_WHITE);
  }
  drawNextNav();
  paintChipRow();
}

void drawSky() {
  gfx->fillScreen(COL_BG);
  titleRow("TEMP", false);
    bool tall = SH >= 400;
  gfx->setTextSize(tall ? 3 : 1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(8, tall ? 48 : 22);
  gfx->print(CITIES[cityIx].name);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(8, tall ? 80 : 34);
  gfx->print("tap next to pick your city");
  if (!skyOk) {
    gfx->setTextSize(tall ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, tall ? 120 : 52);
    gfx->print(wifiOk ? "waiting on the temp" : "no link yet");
  } else {
    char line[24];
    snprintf(line, sizeof(line), "%.0f %s", skyTemp, useC ? "C" : "F");
    gfx->setTextSize(tall ? 5 : 2);
    gfx->setTextColor(COL_GOLD);
    gfx->setCursor(8, tall ? 110 : 52);
    gfx->print(line);
    gfx->setTextSize(tall ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, tall ? 180 : 74);
    gfx->print(skyWord(skyCode));
    snprintf(line, sizeof(line), "wind %.0f mph", skyWind);
    gfx->setCursor(8, tall ? 210 : 88);
    gfx->print(line);
  }
  char cityClk[16];
  cityClockText(cityClk, sizeof(cityClk));
  int csz = tall ? 8 : 4;
  int ctw = (int)strlen(cityClk) * 6 * csz;
  int cx = SW - 16 - ctw;
  int minx = tall ? 280 : 200;
  while (csz > 2 && cx < minx) {
    csz--;
    ctw = (int)strlen(cityClk) * 6 * csz;
    cx = SW - 16 - ctw;
  }
  gfx->setTextSize(csz);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(cx, tall ? 120 : 48);
  gfx->print(cityClk);
  int y = skyY();
  int bh = tall ? 36 : 20;
  gfx->fillRoundRect(8, y, 100, bh, 4, COL_CARD);
  gfx->fillRoundRect(116, y, 100, bh, 4, COL_CARD);
  gfx->fillRoundRect(224, y, 80, bh, 4, COL_CARD);
  gfx->setTextSize(tall ? 2 : 1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(28, y + (tall ? 10 : 6));
  gfx->print("PREV");
  gfx->setCursor(136, y + (tall ? 10 : 6));
  gfx->print("NEXT");
  gfx->setCursor(250, y + (tall ? 10 : 6));
  gfx->print(useC ? "F" : "C");
  paintChipRow();
}

void teamBox(int i, int *x, int *y, int *w, int *h) {
  int cols = 8;
  int rows = 4;
  int top = SH >= 400 ? 48 : 22;
  int bw = (SW - 16) / cols;
  int bh = (SH - top - (SH >= 400 ? 60 : 28)) / rows;
  *x = 8 + (i % cols) * bw;
  *y = top + (i / cols) * bh;
  *w = bw - 4;
  *h = bh - 4;
}

bool sameClub(const char *a, const char *b) {
  if (!a || !b || !a[0] || !b[0]) return false;
  if (strcmp(a, b) == 0) return true;
  if ((strcmp(a, "WAS") == 0 || strcmp(a, "WSH") == 0) &&
      (strcmp(b, "WAS") == 0 || strcmp(b, "WSH") == 0))
    return true;
  return false;
}

bool clubInGame(const Kick *g, const char *ab) {
  return hasTeam(g->name, ab) || sameClub(g->away, ab) || sameClub(g->home, ab);
}

bool findClubGame(const char *ab, Kick *out) {
  Kick view[16];
  int n = copyGames(view);
  int pre = -1;
  int any = -1;
  for (int i = 0; i < n; i++) {
    if (!clubInGame(&view[i], ab)) continue;
    if (strcmp(view[i].state, "in") == 0) {
      *out = view[i];
      return true;
    }
    if (pre < 0 && strcmp(view[i].state, "pre") == 0) pre = i;
    if (any < 0) any = i;
  }
  if (pre >= 0) {
    *out = view[pre];
    return true;
  }
  if (any >= 0) {
    *out = view[any];
    return true;
  }
  n = copyToday(view);
  for (int i = 0; i < n; i++) {
    if (!clubInGame(&view[i], ab)) continue;
    *out = view[i];
    return true;
  }
  return false;
}

void drawTeam() {
  gfx->fillScreen(COL_BG);
  titleRow("TEAM", false);
  if (fav[0]) {
    Kick g;
    if (findClubGame(fav, &g)) {
      char line[72];
      snprintf(line, sizeof(line), "%s  %s-%s  %s", g.name,
               g.aPts[0] ? g.aPts : "-",
               g.hPts[0] ? g.hPts : "-",
               g.detail);
      gfx->setTextSize(SH >= 400 ? 2 : 1);
      gfx->setTextColor(COL_WHITE);
      gfx->setCursor(SH >= 400 ? 120 : 48, SH >= 400 ? 22 : 4);
      gfx->print(line);
    }
  }
  for (int i = 0; i < N_TEAMS; i++) {
    int x, y, w, h;
    teamBox(i, &x, &y, &w, &h);
    bool on = strcmp(fav, TEAMS[i]) == 0;
    gfx->fillRoundRect(x, y, w, h, 6, on ? COL_GOLD : COL_CARD);
    int tsz = (SH >= 400 && h >= 40) ? 2 : 1;
    gfx->setTextSize(tsz);
    gfx->setTextColor(on ? COL_BG : COL_WHITE);
    int tw = (int)strlen(TEAMS[i]) * 6 * tsz;
    gfx->setCursor(x + (w - tw) / 2, y + (h - 8 * tsz) / 2);
    gfx->print(TEAMS[i]);
  }
  paintChipRow();
}

void addKey(int x, int y, int w, int h, int code, const char *s) {
  gfx->fillRoundRect(x, y, w, h, 4, COL_CARD);
  gfx->setTextSize(SH >= 400 ? 2 : 1);
  gfx->setTextColor(COL_WHITE);
  int tw = (int)strlen(s) * 6 * (SH >= 400 ? 2 : 1);
  gfx->setCursor(x + (w - tw) / 2, y + (h - 8 * (SH >= 400 ? 2 : 1)) / 2);
  gfx->print(s);
  if (nKeys < 48) {
    keys[nKeys].x = (int16_t)x;
    keys[nKeys].y = (int16_t)y;
    keys[nKeys].w = (int16_t)w;
    keys[nKeys].h = (int16_t)h;
    keys[nKeys].code = (int16_t)code;
    nKeys++;
  }
}

void drawKeyRows(int y, int kh) {
  const char *r1 = keysNum ? "1234567890" : "qwertyuiop";
  const char *r2 = keysNum ? "-_.:@#+=/" : "asdfghjkl";
  const char *r3 = keysNum ? "()!?'" : "zxcvbnm";
  int gap = 4;
  int w1 = (SW - 8 - 9 * gap) / 10;
  for (int i = 0; r1[i]; i++) {
    char lab[2] = {r1[i], 0};
    addKey(4 + i * (w1 + gap), y, w1, kh - 2, r1[i], lab);
  }
  int n2 = (int)strlen(r2);
  int w2 = w1;
  int x2 = (SW - (n2 * w2 + (n2 - 1) * gap)) / 2;
  for (int i = 0; i < n2; i++) {
    char lab[2] = {r2[i], 0};
    addKey(x2 + i * (w2 + gap), y + kh, w2, kh - 2, r2[i], lab);
  }
  int n3 = (int)strlen(r3);
  for (int i = 0; i < n3; i++) {
    char lab[2] = {r3[i], 0};
    addKey(4 + i * (w1 + gap), y + kh * 2, w1, kh - 2, r3[i], lab);
  }
  addKey(4 + n3 * (w1 + gap), y + kh * 2, w1 * 2, kh - 2, 8, "DEL");
  addKey(4, y + kh * 3, 80, kh - 2, 1, "123");
  addKey(90, y + kh * 3, SW - 180, kh - 2, ' ', "SPACE");
}

void wifiGeom(int *scanY, int *ssidY, int *passY, int *keyY, int *actY, int *kh, int *fieldH) {
  if (SH >= 400) {
    *scanY = 40;
    *ssidY = 96;
    *passY = 146;
    *keyY = 210;
    *actY = 400;
    *kh = 34;
    *fieldH = 40;
  } else {
    *scanY = 22;
    *ssidY = 44;
    *passY = 68;
    *keyY = 94;
    *actY = 196;
    *kh = 22;
    *fieldH = 22;
  }
}

void drawWifi() {
  nKeys = 0;
  int scanY, ssidY, passY, keyY, actY, kh, fieldH;
  wifiGeom(&scanY, &ssidY, &passY, &keyY, &actY, &kh, &fieldH);
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, 4);
  gfx->print("WIFI");
  int nShow = SW >= 700 ? 4 : 2;
  gfx->setTextSize(1);
  gfx->setTextColor(COL_DIM);
  if (SH >= 400) {
    gfx->setCursor(8, scanY - 12);
    gfx->print(nScan ? "tap a network" : "scanning");
  }
  int sw = (SW - 16) / nShow;
  int shBtn = SH >= 400 ? 28 : 18;
  for (int i = 0; i < nScan && i < nShow; i++) {
    gfx->fillRoundRect(8 + i * sw, scanY, sw - 4, shBtn, 4, COL_CARD);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(12 + i * sw, scanY + 4);
    gfx->print(scanName[i]);
  }
  gfx->fillRoundRect(8, ssidY, SW - 16, fieldH, 6, COL_CARD);
  gfx->drawRoundRect(8, ssidY, SW - 16, fieldH, 6, wifiFocus == 0 ? COL_GOLD : COL_LINE);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(12, ssidY + 4);
  if (fieldH > 30) gfx->print("name");
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(fieldH > 30 ? 16 : 52, ssidY + (fieldH > 30 ? 18 : 6));
  gfx->print(wifiSsid);
  gfx->fillRoundRect(8, passY, SW - 16, fieldH, 6, COL_CARD);
  gfx->drawRoundRect(8, passY, SW - 16, fieldH, 6, wifiFocus == 1 ? COL_GOLD : COL_LINE);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(12, passY + 4);
  if (fieldH > 30) gfx->print("password");
  else gfx->print("pw");
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(fieldH > 30 ? 16 : 36, passY + (fieldH > 30 ? 18 : 6));
  gfx->print(wifiPass);
  drawKeyRows(keyY, kh);
  int bw = (SW - 20) / 4;
  int ah = SH >= 400 ? 40 : 28;
  const char *acts[] = {"JOIN", "FORGET", "BACK", "RESET"};
  for (int i = 0; i < 4; i++) {
    int x = 4 + i * (bw + 4);
    gfx->fillRoundRect(x, actY, bw, ah, 6, i == 0 ? COL_GOLD : COL_CARD);
    gfx->setTextSize(SH >= 400 ? 2 : 1);
    gfx->setTextColor(i == 0 ? COL_BG : COL_WHITE);
    int tw = (int)strlen(acts[i]) * 6 * (SH >= 400 ? 2 : 1);
    gfx->setCursor(x + (bw - tw) / 2, actY + (ah - 8 * (SH >= 400 ? 2 : 1)) / 2);
    gfx->print(acts[i]);
  }
}

void typeKey(int code) {
  char *buf = wifiFocus == 0 ? wifiSsid : wifiPass;
  int cap = wifiFocus == 0 ? (int)sizeof(wifiSsid) : (int)sizeof(wifiPass);
  int n = (int)strlen(buf);
  if (code == 8) {
    if (n > 0) buf[n - 1] = 0;
  } else if (code == 1) {
    keysNum = !keysNum;
  } else if (code >= 32 && code < 127 && n < cap - 1) {
    buf[n] = (char)code;
    buf[n + 1] = 0;
  }
  drawWifi();
}

void startScan() {
  scanWait = true;
  nScan = 0;
  WiFi.mode(WIFI_STA);
  WiFi.scanNetworks(true);
}

void joinWifi() {
  savePrefs();
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.disconnect();
  delay(100);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) delay(50);
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (wifiOk) {
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    applyTz();
    page = PG_BOARD;
    lastGames = 0;
    drawBoard();
  } else drawWifi();
}

void updBox() {
  updBh = SH >= 400 ? 48 : 30;
  updBw = SH >= 400 ? 360 : 220;
  updX = (SW - updBw) / 2;
  updY1 = SH >= 400 ? 150 : 72;
  updY2 = updY1 + updBh + (SH >= 400 ? 14 : 8);
}

void drawUpd() {
  updBox();
  gfx->fillScreen(COL_BG);
  titleRow("UPDATE", false);
  char line[48];
  snprintf(line, sizeof(line), "version  %s", KICK_VER);
  centreAt(line, SH >= 400 ? 46 : 34, SH >= 400 ? 2 : 1, COL_WHITE);
  gfx->fillRoundRect(updX, updY1, updBw, updBh, 6, COL_CARD);
  gfx->fillRoundRect(updX, updY2, updBw, updBh, 6, otaNewer ? COL_GOLD : COL_CARD);
  int ts = SH >= 400 ? 2 : 1;
  gfx->setTextSize(ts);
  gfx->setTextColor(COL_WHITE);
  int tw = 5 * 6 * ts;
  gfx->setCursor(updX + (updBw - tw) / 2, updY1 + (updBh - 8 * ts) / 2);
  gfx->print("CHECK");
  gfx->setTextColor(otaNewer ? COL_BG : COL_WHITE);
  tw = 7 * 6 * ts;
  gfx->setCursor(updX + (updBw - tw) / 2, updY2 + (updBh - 8 * ts) / 2);
  gfx->print("INSTALL");
  int my = updY2 + updBh + (SH >= 400 ? 16 : 6);
  centreAt(otaMsg[0] ? otaMsg : "check for updates", my, SH >= 400 ? 2 : 1, COL_DIM);
  if (otaPct >= 0) {
    int bw = SW - 40;
    int bh = SH >= 400 ? 18 : 10;
    int by = SH - (SH >= 400 ? 70 : 50);
    gfx->drawRect(20, by, bw, bh, COL_DIM);
    int w = (bw * (otaPct > 100 ? 100 : otaPct)) / 100;
    if (w > 0) gfx->fillRect(20, by, w, bh, COL_GOLD);
  }
  snprintf(line, sizeof(line), "loads %s", KICK_BIN);
  centreAt(line, SH - (SH >= 400 ? 88 : 62), 1, COL_DIM);
  paintChipRow();
}

int verPack(const char *s) {
  if (!s || !s[0]) return 0;
  int a = 0, b = 0;
  while (*s && !isdigit((unsigned char)*s)) s++;
  while (*s && isdigit((unsigned char)*s)) a = a * 10 + (*s++ - '0');
  if (*s == '.') s++;
  while (*s && isdigit((unsigned char)*s)) b = b * 10 + (*s++ - '0');
  return a * 100 + b;
}

void trimWord(char *s) {
  if (!s) return;
  char *a = s;
  while (*a && isspace((unsigned char)*a)) a++;
  char *e = a + strlen(a);
  while (e > a && isspace((unsigned char)e[-1])) e--;
  *e = 0;
  if (a != s) memmove(s, a, (size_t)(e - a) + 1);
}

void otaNote(const char *s) {
  strlcpy(otaMsg, s ? s : "", sizeof(otaMsg));
  otaRev++;
}

void otaUrl(char *url, int cap, const char *file) {
  snprintf(url, cap, "https://raw.githubusercontent.com/%s/%s/main/ota/%s", KICK_GH_USER, KICK_GH_REPO, file);
}

bool httpText(const char *url, char *body, int cap) {
  body[0] = 0;
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setTimeout(20000);
  http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, url)) return false;
  int code = http.GET();
  if (code == 200) {
    WiFiClient *stream = http.getStreamPtr();
    int got = 0;
    uint32_t t0 = millis();
    while (got < cap - 1 && millis() - t0 < 15000) {
      int a = stream->available();
      if (a <= 0) {
        if (!http.connected()) break;
        delay(2);
        continue;
      }
      if (a > cap - 1 - got) a = cap - 1 - got;
      int r = stream->read((uint8_t *)body + got, a);
      if (r <= 0) break;
      got += r;
    }
    body[got] = 0;
  }
  http.end();
  cli.stop();
  return code == 200 && body[0];
}

void otaCheck() {
  otaNewer = 0;
  otaLatest[0] = 0;
  if (WiFi.status() != WL_CONNECTED) {
    otaNote("join wifi first");
    return;
  }
  char url[140];
  otaUrl(url, sizeof(url), "version.txt");
  char body[48];
  if (!httpText(url, body, sizeof(body))) {
    otaNote("could not reach github");
    return;
  }
  trimWord(body);
  if (!body[0] || strlen(body) > 10) {
    otaNote("bad version file");
    return;
  }
  strlcpy(otaLatest, body, sizeof(otaLatest));
  if (verPack(otaLatest) > verPack(KICK_VER)) {
    otaNewer = 1;
    char msg[48];
    snprintf(msg, sizeof(msg), "version %s  tap INSTALL", otaLatest);
    otaNote(msg);
  } else {
    otaNote("newest firmware already installed");
  }
}

void otaFlash() {
  if (WiFi.status() != WL_CONNECTED) {
    otaNote("join wifi first");
    return;
  }
  if (!otaNewer) {
    otaNote("check first");
    return;
  }
  if (!esp_ota_get_next_update_partition(NULL)) {
    otaNote("no update slot");
    return;
  }
  otaNote("downloading  do not unplug");
  otaPct = 0;
  otaRev++;
  char url[140];
  otaUrl(url, sizeof(url), KICK_BIN);
  WiFiClientSecure cli;
  cli.setInsecure();
  HTTPClient http;
  http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
  http.setTimeout(180000);
  http.setUserAgent("KickoffDesk/1.0");
  if (!http.begin(cli, url)) {
    otaNote("download fail");
    return;
  }
  int code = http.GET();
  int len = http.getSize();
  if (code != 200 || len < 100000) {
    http.end();
    otaNote(code != 200 ? "download fail" : "file too small");
    return;
  }
  if (!Update.begin((size_t)len)) {
    http.end();
    otaNote("flash begin fail");
    return;
  }
  WiFiClient *stream = http.getStreamPtr();
  size_t got = 0;
  uint8_t buf[1024];
  while (got < (size_t)len) {
    int n = stream->readBytes(buf, sizeof(buf));
    if (n <= 0) {
      if (!http.connected()) break;
      delay(2);
      continue;
    }
    if (Update.write(buf, (size_t)n) != (size_t)n) {
      Update.abort();
      http.end();
      otaNote("flash write fail");
      return;
    }
    got += (size_t)n;
    int p = (int)((got * 100UL) / (size_t)len);
    if (p != otaPct) {
      otaPct = p;
      otaRev++;
    }
  }
  http.end();
  if (got != (size_t)len || !Update.end(true)) {
    otaNote("download fail");
    return;
  }
  otaPct = 100;
  otaNote("done  rebooting");
  delay(800);
  ESP.restart();
}

void runOtaJob() {
  if (otaKind == 1) otaCheck();
  else if (otaKind == 2) otaFlash();
  otaKind = 0;
  otaBusy = 0;
  otaRev++;
}

void askOta(int kind) {
  if (otaBusy || job != 0) {
    otaNote("busy");
    return;
  }
  otaKind = kind;
  otaPct = kind == 2 ? 0 : -1;
  otaNote(kind == 1 ? "checking" : "starting update");
  otaBusy = 1;
  job = 3;
}

void tapUpd(int x, int y) {
  if (otaBusy) return;
  updBox();
  if (hit(x, y, updX, updY1, updX + updBw, updY1 + updBh)) askOta(1);
  else if (hit(x, y, updX, updY2, updX + updBw, updY2 + updBh)) askOta(2);
}

void seasonWindow(int n, int *rowsOut, int *visOut, int *rhOut, int *topOut) {
  int rows = n > 0 ? (n + 1) / 2 : 1;
  int top = SH >= 400 ? 52 : 22;
  int bot = SH >= 400 ? SH - 58 : SH - 26;
  int rh = SH >= 400 ? 28 : 18;
  int vis = (bot - top) / rh;
  if (vis < 1) vis = 1;
  if (vis > rows) vis = rows;
  if (rowsOut) *rowsOut = rows;
  if (visOut) *visOut = vis;
  if (rhOut) *rhOut = rh;
  if (topOut) *topOut = top;
}

void drawSeason() {
  gfx->fillScreen(COL_BG);
  titleRow("LEADERS", true, true);
  SeasonRow row[32];
  int n = season.n;
  if (n < 0) n = 0;
  if (n > 32) n = 32;
  for (int i = 0; i < n; i++) row[i] = season.row[i];
  for (int i = 1; i < n; i++) {
    SeasonRow key = row[i];
    int j = i;
    while (j > 0) {
      int g0 = row[j - 1].w + row[j - 1].l + row[j - 1].t;
      int gk = key.w + key.l + key.t;
      int p0 = g0 ? (row[j - 1].w * 1000) / g0 : 0;
      int pk = gk ? (key.w * 1000) / gk : 0;
      bool worse = p0 < pk || (p0 == pk && row[j - 1].w < key.w) ||
                   (p0 == pk && row[j - 1].w == key.w && row[j - 1].l > key.l);
      if (!worse) break;
      row[j] = row[j - 1];
      j--;
    }
    row[j] = key;
  }
  if (n <= 0) {
    gfx->setTextSize(SH >= 400 ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, SH >= 400 ? 80 : 40);
    gfx->print(wifiOk ? "reading the board" : "no link yet");
    paintChipRow();
    return;
  }
  int rows = 1, vis = 1, rh = 28, top = 52;
  seasonWindow(n, &rows, &vis, &rh, &top);
  if (seasonTop > rows - vis) seasonTop = rows - vis;
  if (seasonTop < 0) seasonTop = 0;
  int cw = (SW - 16) / 2;
  int ts = (rh >= 20 && SH >= 400) ? 2 : 1;
  for (int i = 0; i < n; i++) {
    int c = i / rows;
    int r = i % rows;
    if (r < seasonTop || r >= seasonTop + vis) continue;
    int x = 8 + c * cw;
    int y = top + (r - seasonTop) * rh;
    char line[20];
    if (row[i].t)
      snprintf(line, sizeof(line), "%s  %u-%u-%u", row[i].ab, row[i].w, row[i].l, row[i].t);
    else
      snprintf(line, sizeof(line), "%s  %u-%u", row[i].ab, row[i].w, row[i].l);
    gfx->setTextSize(ts);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(x, y);
    gfx->print(line);
  }
  paintChipRow();
}

int copySoon(Kick *dst) {
  if (gameLock) xSemaphoreTake(gameLock, portMAX_DELAY);
  int n = nSoon;
  if (n > 24) n = 24;
  if (n > 0) memcpy(dst, soon, sizeof(Kick) * n);
  if (gameLock) xSemaphoreGive(gameLock);
  return n;
}

void drawWeek() {
  static Kick view[24];
  int n = copySoon(view);
  int vis = 1;
  bool scroll = todayNeedsScroll(n, &vis);
  int cols = (SW < 700 && n > 6) ? 2 : 1;
  int rows = n <= 0 ? 0 : (n + cols - 1) / cols;
  if (soonTop > rows - vis) soonTop = rows - vis;
  if (soonTop < 0) soonTop = 0;
  gfx->fillScreen(COL_BG);
  titleRow("7 DAYS", scroll);
  drawDayBtn(true, scroll);
  int top = SH >= 400 ? 52 : 22;
  if (n <= 0) {
    gfx->setTextSize(SH >= 400 ? 2 : 1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(8, top + 8);
    gfx->print(busy ? "reading the board" : "no games in the next 7 days");
    paintChipRow();
    return;
  }
  int rh = SH >= 400 ? 22 : 16;
  int ts = (rh >= 20 && SW >= 700) ? 2 : 1;
  int cw = (SW - 16) / cols;
  for (int i = 0; i < n; i++) {
    int c = i / rows;
    int r = i % rows;
    if (r < soonTop || r >= soonTop + vis) continue;
    int x = 8 + c * cw;
    int y = top + (r - soonTop) * rh;
    char line[64];
    snprintf(line, sizeof(line), "%s  %s", view[i].name, view[i].detail);
    gfx->setTextSize(ts);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(x, y);
    gfx->print(line);
  }
  paintChipRow();
}

void openWeek() {
  page = PG_WEEK;
  soonTop = 0;
  if (wifiOk && !busy && (lastSoon == 0 || millis() - lastSoon > 600000UL)) {
    busy = true;
    job = 5;
  }
  drawWeek();
}

void redraw() {
  if (page == PG_BOARD) drawBoard();
  else if (page == PG_NEXT) drawNext();
  else if (page == PG_SKY) drawSky();
  else if (page == PG_TEAM) drawTeam();
  else if (page == PG_WIFI) drawWifi();
  else if (page == PG_SEASON) drawSeason();
  else if (page == PG_TODAY) drawToday();
  else if (page == PG_WEEK) drawWeek();
  else drawUpd();
}

void cycleTz() {
  tzIx = (tzIx + 1) % 4;
  applyTz();
  savePrefs();
  shownMin = -1;
  redraw();
}

void openSeason() {
  page = PG_SEASON;
  drawSeason();
  if (wifiOk && !busy) {
    busy = true;
    job = 4;
  }
}

void tapSeason(int x, int y) {
  int sx, sy, sw, sh;
  seasonAt(&sx, &sy, &sw, &sh, true);
  if (hit(x, y, sx - 2, sy - 2, sx + sw + 2, sy + sh + 2)) {
    page = PG_BOARD;
    drawBoard();
    return;
  }
  int rows = 1, vis = 1;
  seasonWindow(season.n, &rows, &vis, nullptr, nullptr);
  bool up = false;
  bool dn = false;
  if (SH >= 400) {
    up = hit(x, y, SW - 156, 14, SW - 86, 42);
    dn = hit(x, y, SW - 78, 14, SW - 8, 42);
  } else {
    up = hit(x, y, SW - 108, 0, SW - 56, 20);
    dn = hit(x, y, SW - 54, 0, SW - 4, 20);
  }
  if (up) {
    if (seasonTop > 0) seasonTop -= vis;
    if (seasonTop < 0) seasonTop = 0;
    drawSeason();
    return;
  }
  if (dn) {
    if (seasonTop + vis < rows) seasonTop += vis;
    drawSeason();
    return;
  }
  if (hit(x, y, clkDrawX, 0, clkDrawX + 170, SH >= 400 ? 44 : 22)) cycleTz();
}

bool liveByClub(const char *ab, char *out, int cap) {
  Kick g;
  if (!findClubGame(ab, &g)) return false;
  strlcpy(out, g.name, cap);
  return true;
}

void openFocus(const char *name) {
  strlcpy(focusName, name, sizeof(focusName));
  gTop = 0;
  page = PG_BOARD;
  drawBoard();
}

void tapBoard(int x, int y) {
  Kick view[16];
  int n = copyGames(view);
  n = focusGame(view, n);
  if (focusName[0]) {
    int bx, by, bw, bh;
    backAt(&bx, &by, &bw, &bh);
    if (hit(x, y, bx, by, bx + bw, by + bh)) {
      focusName[0] = 0;
      drawBoard();
      return;
    }
    clearAt(&bx, &by, &bw, &bh);
    if (hit(x, y, bx, by, bx + bw, by + bh)) {
      clearPlaying(focusName);
      drawBoard();
      return;
    }
  }
  int sx, sy, sw, sh;
  seasonAt(&sx, &sy, &sw, &sh, scrollOn(n));
  if (hit(x, y, sx - 2, sy - 2, sx + sw + 2, sy + sh + 2)) {
    openSeason();
    return;
  }
  if (scrollOn(n)) {
    int vis = boardRows() * boardCols();
    if (hit(x, y, SW - 108, 0, SW - 56, 20)) {
      if (gTop >= vis) gTop -= vis;
      drawBoard();
      return;
    }
    if (hit(x, y, SW - 54, 0, SW - 4, 20)) {
      if (gTop + vis < n) gTop += vis;
      drawBoard();
      return;
    }
  }
  int cols = focusName[0] ? 1 : boardCols();
  int gap = SH >= 400 ? 6 : 4;
  int cw = (SW - 12 - gap * (cols - 1)) / cols;
  int ch = cardH();
  int y0 = SH >= 400 ? 48 : 24;
  int vis = boardRows() * cols;
  int shown = 0;
  for (int i = gTop; i < n && shown < vis; i++, shown++) {
    int col = shown % cols;
    int row = shown / cols;
    int cx = 6 + col * (cw + gap);
    int cy = y0 + row * (ch + gap);
    if (hit(x, y, cx, cy, cx + cw, cy + ch)) {
      openFocus(view[i].name);
      return;
    }
  }
  if (hit(x, y, clkDrawX, 0, clkDrawX + 100, 20)) cycleTz();
}

int skyY() { return SH >= 400 ? 360 : 200; }

void tapSky(int x, int y) {
  if (hit(x, y, clockX(false), 0, clockX(false) + 100, 20)) {
    cycleTz();
    return;
  }
  int yb = skyY();
  int bh = SH >= 400 ? 36 : 20;
  if (hit(x, y, 8, yb, 108, yb + bh)) {
    cityIx = (cityIx + N_CITIES - 1) % N_CITIES;
    skyOk = false;
    cityOffOk = false;
    savePrefs();
    drawSky();
    if (wifiOk && !busy) {
      busy = true;
      job = 2;
    }
    return;
  }
  if (hit(x, y, 116, yb, 216, yb + bh)) {
    cityIx = (cityIx + 1) % N_CITIES;
    skyOk = false;
    cityOffOk = false;
    savePrefs();
    drawSky();
    if (wifiOk && !busy) {
      busy = true;
      job = 2;
    }
    return;
  }
  if (hit(x, y, 224, yb, 304, yb + bh)) {
    useC = !useC;
    skyOk = false;
    savePrefs();
    drawSky();
    if (wifiOk && !busy) {
      busy = true;
      job = 2;
    }
  }
}

void tapTeam(int x, int y) {
  for (int i = 0; i < N_TEAMS; i++) {
    int bx, by, bw, bh;
    teamBox(i, &bx, &by, &bw, &bh);
    if (hit(x, y, bx, by, bx + bw, by + bh)) {
      char game[20];
      strlcpy(fav, TEAMS[i], sizeof(fav));
      savePrefs();
      if (liveByClub(TEAMS[i], game, sizeof(game))) {
        openFocus(game);
        return;
      }
      drawTeam();
      return;
    }
  }
}

void tapWifi(int x, int y) {
  int scanY, ssidY, passY, keyY, actY, kh, fieldH;
  wifiGeom(&scanY, &ssidY, &passY, &keyY, &actY, &kh, &fieldH);
  int nShow = SW >= 700 ? 4 : 2;
  int sw = (SW - 16) / nShow;
  (void)keyY;
  (void)kh;
  for (int i = 0; i < nScan && i < nShow; i++) {
    int shBtn = SH >= 400 ? 28 : 18;
    if (hit(x, y, 8 + i * sw, scanY, 8 + i * sw + sw - 4, scanY + shBtn)) {
      strlcpy(wifiSsid, scanName[i], sizeof(wifiSsid));
      wifiFocus = 1;
      drawWifi();
      return;
    }
  }
  if (hit(x, y, 8, ssidY, SW - 8, ssidY + fieldH)) {
    wifiFocus = 0;
    drawWifi();
    return;
  }
  if (hit(x, y, 8, passY, SW - 8, passY + fieldH)) {
    wifiFocus = 1;
    drawWifi();
    return;
  }
  for (int i = 0; i < nKeys; i++) {
    if (hit(x, y, keys[i].x, keys[i].y, keys[i].x + keys[i].w, keys[i].y + keys[i].h)) {
      typeKey(keys[i].code);
      return;
    }
  }
  int bw = (SW - 20) / 4;
  int ah = SH >= 400 ? 40 : 28;
  if (hit(x, y, 4, actY, 4 + bw, actY + ah)) {
    joinWifi();
    return;
  }
  if (hit(x, y, 4 + (bw + 4), actY, 4 + (bw + 4) + bw, actY + ah)) {
    wifiSsid[0] = wifiPass[0] = 0;
    savePrefs();
    WiFi.disconnect(true, true);
    drawWifi();
    return;
  }
  if (hit(x, y, 4 + 2 * (bw + 4), actY, 4 + 2 * (bw + 4) + bw, actY + ah)) {
    page = PG_BOARD;
    drawBoard();
    return;
  }
  if (hit(x, y, 4 + 3 * (bw + 4), actY, 4 + 3 * (bw + 4) + bw, actY + ah)) {
    prefs.begin(PREF_NS, false);
    prefs.clear();
    prefs.end();
    delay(100);
    ESP.restart();
  }
}

void onTap(int x, int y) {
  if (page != PG_WIFI) {
    for (int i = 0; i < 6; i++) {
      if (chipHit(x, y, i)) {
        if (i == PG_WIFI) {
          page = PG_WIFI;
          startScan();
          drawWifi();
        } else {
          page = i;
          redraw();
          if (page == PG_SKY && wifiOk && !busy) {
            busy = true;
            job = 2;
          }
        }
        return;
      }
    }
  }
  if (page == PG_BOARD) tapBoard(x, y);
  else if (page == PG_NEXT) {
    int x0, y0, w0, h0, x1, y1, w1, h1;
    nextNavBox(0, &x0, &y0, &w0, &h0);
    nextNavBox(1, &x1, &y1, &w1, &h1);
    if (hit(x, y, x0, y0, x0 + w0, y0 + h0)) {
      page = PG_BOARD;
      drawBoard();
      return;
    }
    if (hit(x, y, x1, y1, x1 + w1, y1 + h1)) {
      page = PG_TODAY;
      drawToday();
      return;
    }
    int xw, yw, ww, hw;
    weekAt(&xw, &yw, &ww, &hw);
    if (hit(x, y, xw, yw, xw + ww, yw + hw)) {
      openWeek();
      return;
    }
    if (hit(x, y, clockX(false), 0, SW - 4, 32)) cycleTz();
  } else if (page == PG_TODAY) {
    int vis = 1;
    bool scroll = todayNeedsScroll(nToday, &vis);
    int sx, sy, sw, sh;
    seasonAt(&sx, &sy, &sw, &sh, scroll);
    if (hit(x, y, sx, sy, sx + sw, sy + sh)) {
      page = PG_NEXT;
      drawNext();
      return;
    }
    if (scroll) {
      bool up = false;
      bool dn = false;
      if (SH >= 400) {
        up = hit(x, y, SW - 156, 14, SW - 86, 42);
        dn = hit(x, y, SW - 78, 14, SW - 8, 42);
      } else {
        up = hit(x, y, SW - 108, 0, SW - 56, 20);
        dn = hit(x, y, SW - 54, 0, SW - 4, 20);
      }
      if (up) {
        if (todayTop >= vis) todayTop -= vis;
        drawToday();
        return;
      }
      if (dn) {
        todayTop += vis;
        drawToday();
        return;
      }
    }
    if (hit(x, y, clockX(false), 0, SW - 4, 32)) cycleTz();
  } else if (page == PG_WEEK) {
    int vis = 1;
    bool scroll = todayNeedsScroll(nSoon, &vis);
    int sx, sy, sw, sh;
    seasonAt(&sx, &sy, &sw, &sh, scroll);
    if (hit(x, y, sx, sy, sx + sw, sy + sh)) {
      page = PG_NEXT;
      drawNext();
      return;
    }
    if (scroll) {
      bool up = false;
      bool dn = false;
      if (SH >= 400) {
        up = hit(x, y, SW - 156, 14, SW - 86, 42);
        dn = hit(x, y, SW - 78, 14, SW - 8, 42);
      } else {
        up = hit(x, y, SW - 108, 0, SW - 56, 20);
        dn = hit(x, y, SW - 54, 0, SW - 4, 20);
      }
      if (up) {
        if (soonTop >= vis) soonTop -= vis;
        drawWeek();
        return;
      }
      if (dn) {
        soonTop += vis;
        drawWeek();
        return;
      }
    }
    if (hit(x, y, clockX(false), 0, SW - 4, 32)) cycleTz();
  } else if (page == PG_UPD) tapUpd(x, y);
  else if (page == PG_SKY) tapSky(x, y);
  else if (page == PG_TEAM) tapTeam(x, y);
  else if (page == PG_SEASON) tapSeason(x, y);
  else tapWifi(x, y);
}

bool anyLive() {
  Kick view[16];
  int n = copyGames(view);
  for (int i = 0; i < n; i++)
    if (strcmp(view[i].state, "in") == 0) return true;
  return false;
}

void connectWifi() {
  loadPrefs();
  if (!wifiSsid[0]) {
    page = PG_WIFI;
    startScan();
    drawWifi();
    return;
  }
  page = PG_BOARD;
  gfx->fillScreen(COL_BG);
  gfx->setTextColor(COL_WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(8, 80);
  gfx->print("linking");
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(50);
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (wifiOk) {
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    applyTz();
  }
  drawBoard();
}

void pollScan() {
  if (!scanWait || page != PG_WIFI) return;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return;
  scanWait = false;
  if (n < 0) return;
  nScan = n > 4 ? 4 : n;
  for (int i = 0; i < nScan; i++) strlcpy(scanName[i], WiFi.SSID(i).c_str(), sizeof(scanName[i]));
  WiFi.scanDelete();
  drawWifi();
}

void setup() {
  Serial.begin(115200);
  pinMode(GFX_BL, OUTPUT);
  digitalWrite(GFX_BL, HIGH);
  SPI.begin(TOUCH_SCK, TOUCH_MISO, TOUCH_MOSI, TOUCH_CS);
  ts.begin();
  ts.setRotation(0);
  rgbBus = new Arduino_ESP32RGBPanel(
      PIN_DE, PIN_VSYNC, PIN_HSYNC, PIN_PCLK,
      45, 48, 47, 21, 14,
      5, 6, 7, 15, 16, 4,
      8, 3, 46, 9, 1,
      0, 8, 4, 43,
      0, 8, 4, 12,
      1, 9000000, false, 0, 0, 272 * 40);
  gfx = new Arduino_RGB_Display(SW, SH, rgbBus, 2, true);
  if (!gfx->begin()) {
    Serial.println("gfx begin failed");
    return;
  }
  gfx->setTextWrap(false);
  digitalWrite(GFX_BL, HIGH);
  gameLock = xSemaphoreCreateMutex();
  loadSeason();
  xTaskCreatePinnedToCore(netTask, "kicknet", 40960, nullptr, 1, nullptr, 0);
  connectWifi();
  lastTap = millis();
  redraw();
  shownAt = millis();
}

void loop() {
  if (page == PG_UPD && otaRev != shownRev) {
    shownRev = otaRev;
    drawUpd();
  }
  if (otaBusy) {
    delay(8);
    return;
  }
  if (shownAt && millis() - shownAt > 700) {
    shownAt = 0;
    redraw();
  }
  pollScan();
  int x, y;
  if (readFinger(&x, &y) == 1 && millis() - lastTap > 180) {
    lastTap = millis();
    onTap(x, y);
  }
  if (shiftFix && !busy && rgbBus) {
    shiftFix = false;
    rgbBus->restartPanel();
    dirty = true;
  }
  if (dirty && !busy) {
    dirty = false;
    if (page != PG_WIFI) redraw();
  }
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (!busy && !otaBusy && wifiOk && page != PG_WIFI && page != PG_UPD) {
    uint32_t nowMs = millis();
    uint32_t gap = anyLive() ? 45000UL : 180000UL;
    if ((page == PG_BOARD || page == PG_NEXT || page == PG_TODAY) &&
        (lastGames == 0 || nowMs - lastGames > gap)) {
      busy = true;
      job = 1;
    } else if (!cityOffOk) {
      busy = true;
      job = 2;
    } else if (page == PG_SKY && (lastSky == 0 || nowMs - lastSky > 600000UL)) {
      busy = true;
      job = 2;
    } else if (page == PG_SEASON && (lastSeason == 0 || nowMs - lastSeason > 600000UL)) {
      busy = true;
      job = 4;
    } else if (page == PG_WEEK && (lastSoon == 0 || nowMs - lastSoon > 600000UL)) {
      busy = true;
      job = 5;
    }
  }
  if (page != PG_WIFI) {
    time_t now = time(nullptr);
    if (now > 100000) {
      struct tm t;
      localtime_r(&now, &t);
      int minute = t.tm_hour * 60 + t.tm_min;
      if (minute != shownMin) {
        shownMin = minute;
        rollToday();
        redraw();
      }
    }
  }
  delay(8);
}
